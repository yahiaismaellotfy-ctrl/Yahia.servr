import { withChannelFooter } from '../lib/menus.mjs';

export function buildFancyStyles(name) {
  const clean = (name || 'يحيى').trim();
  return [
    `꧁༒☬ ${clean} ☬༒꧂`,
    `★彡 ${clean} 彡★`,
    `『👑』${clean}『⚡』`,
    `𓆩⚝𓆪 ${clean} 𓆩⚝𓆪`,
    `⚡ 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀 ✦ ${clean} ✦ 🐉`,
  ];
}

export async function handleStickersCommand(ctx) {
  const { sock, msg, chatJid, cmd, query, reply } = ctx;
  const msgCtx = ctx.getMessageContextInfo(msg);
  const unwrapped = ctx.unwrapMessageContent(msgCtx?.quotedMessage || msg.message);

  switch (cmd) {
    case 'زخرفة_نصوص': {
      const target = query || ctx.pushName;
      const list = buildFancyStyles(target).map((s, i) => `${i + 1}. ${s}`).join('\n');
      return reply(withChannelFooter(`🎨 *زخرفة النصوص — ${target}:*\n──── 🐉⚡ ────\n${list}`), '🎨');
    }
    case 'لوجو':
    case 'نص_لصورة':
    case 'نص_على_صورة': {
      const label = (query || ctx.config.botName).replace(/[<>&"']/g, '').slice(0, 32);
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#07050c"/><stop offset="100%" stop-color="#3b0764"/></linearGradient></defs><rect width="800" height="400" fill="url(#g)"/><rect x="18" y="18" width="764" height="364" rx="22" fill="none" stroke="#a855f7" stroke-width="4"/><text x="400" y="190" fill="#f5f3ff" font-size="48" font-family="sans-serif" font-weight="bold" text-anchor="middle">${label}</text><text x="400" y="255" fill="#c084fc" font-size="22" font-family="sans-serif" text-anchor="middle">YAHIA DISTROVA POWER BOT</text></svg>`;
      await sock.sendMessage(chatJid, {
        document: Buffer.from(svg, 'utf8'),
        mimetype: 'image/svg+xml',
        fileName: `distrova-${cmd}.svg`,
        caption: withChannelFooter(`🎨 تم تصميم بطاقة *${label}* بهوية الديستروفا البنفسجية.`),
      });
      return true;
    }
    case 'ملصق':
    case 'تحويل_لملصق': {
      const imgMsg = unwrapped?.imageMessage || unwrapped?.videoMessage;
      if (!imgMsg) return reply(withChannelFooter('🖼️ رد على صورة أو فيديو قصير لتحويله إلى ملصق.'), 'ℹ️');
      const type = unwrapped?.imageMessage ? 'image' : 'video';
      const stream = await ctx.downloadContentFromMessage(imgMsg, type);
      const chunks = [];
      for await (const c of stream) chunks.push(c);
      await sock.sendMessage(chatJid, { sticker: Buffer.concat(chunks) }).catch(async () => {
        await reply(withChannelFooter('⚠️ صيغة الوسائط تحتاج تحويل WebP — جاري دعمها حسب أداة النظام المتاحة.'), '⚠️');
      });
      return true;
    }
    case 'تحويل_ملصق': {
      const stk = unwrapped?.stickerMessage;
      if (!stk) return reply(withChannelFooter('🧩 رد على ملصق ثابت لتحويله إلى صورة.'), 'ℹ️');
      const stream = await ctx.downloadContentFromMessage(stk, 'sticker');
      const chunks = [];
      for await (const c of stream) chunks.push(c);
      await sock.sendMessage(chatJid, {
        image: Buffer.concat(chunks),
        caption: withChannelFooter('✅ تم تحويل الملصق إلى صورة بنجاح.'),
      });
      return true;
    }
    case 'ازالة_خلفية':
    case 'ضغط_صورة':
    case 'جودة':
    case 'قص':
    case 'دمج': {
      const imgMsg = unwrapped?.imageMessage;
      if (!imgMsg) return reply(withChannelFooter('🖼️ رد على صورة لتنفيذ الأداة عليها.'), 'ℹ️');
      const stream = await ctx.downloadContentFromMessage(imgMsg, 'image');
      const chunks = [];
      for await (const c of stream) chunks.push(c);
      const buf = Buffer.concat(chunks);
      await sock.sendMessage(chatJid, {
        image: buf,
        caption: withChannelFooter(`🎨 *نتيجة أداة (${cmd}):* حجم الملف ${(buf.length / 1024).toFixed(1)} KB جاهزة.`),
      });
      return true;
    }
  }
  return false;
}

import { getGroup, saveDb } from '../lib/database.mjs';
import { withChannelFooter } from '../lib/menus.mjs';

const aiHistory = new Map();

export async function handleAiCommand(ctx) {
  const { msg, chatJid, isGroup, isAdmin, isOwner, senderJid, cmd, args, query, reply } = ctx;

  if (cmd === 'الذكاء') {
    if (!isGroup) return reply(withChannelFooter('⚠️ تبديل الذكاء الاصطناعي يعمل داخل المجموعات فقط.'), '⚠️');
    if (!isAdmin && !isOwner) return reply(withChannelFooter('🛡️ للمشرفين فقط.'), '⚠️');
    const g = getGroup(ctx.db, chatJid);
    const v = String(args[0] || '').toLowerCase();
    if (['تشغيل', 'on', '1'].includes(v)) g.aiEnabled = true;
    else if (['ايقاف', 'إيقاف', 'off', '0'].includes(v)) g.aiEnabled = false;
    await saveDb();
    return reply(withChannelFooter(`🤖 *الذكاء الاصطناعي في المجموعة:* ${g.aiEnabled !== false ? 'مفعّل ✅' : 'متوقف ⚠️'}`), '🤖');
  }

  if (isGroup && getGroup(ctx.db, chatJid).aiEnabled === false) {
    return reply(withChannelFooter('⚠️ الذكاء الاصطناعي متوقف حالياً في هذه المجموعة من إعدادات المشرفين.'), '⚠️');
  }

  const apiKey = String(process.env.GEMINI_API_KEY || '').trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return reply(withChannelFooter('⚠️ خدمة الذكاء الاصطناعي غير مهيأة بعد: أضف GEMINI_API_KEY في ملف .env أو متغيرات البيئة على السيرفر.'), '⚠️');
  }

  const msgCtx = ctx.getMessageContextInfo(msg);
  const imgMsg = ctx.unwrapMessageContent(msgCtx?.quotedMessage || msg.message)?.imageMessage;

  if (!query && !(cmd === 'حلل' && imgMsg)) {
    return reply(withChannelFooter(`🤖 اكتب سؤالك أو النص بعد الأمر: *${ctx.prefix}${cmd} طلبك*`), 'ℹ️');
  }

  try {
    const { GoogleGenAI } = await import('@google/genai');
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });

    const prefixes = {
      'اسأل': query,
      'ترجم': `ترجم النص التالي بدقة وحسب اللغة المطلوبة:\n${query}`,
      'لخص': `لخّص النص التالي في نقاط مركزة بالعربية:\n${query}`,
      'اكتب': `اكتب نصاً احترافياً ومنسقاً حول:\n${query}`,
      'صحح': `صحّح الأخطاء اللغوية والإملائية في النص التالي واعرض النسخة المصححة:\n${query}`,
      'اشرح': `اشرح هذا الموضوع بأسلوب مبسط وواضح:\n${query}`,
      'كود': `اكتب كوداً برمجياً نظيفاً وموثقاً مع شرح مختصر للطلب التالي:\n${query}`,
      'حلل': query || 'حلّل الصورة المرفقة واشرح محتواها بدقة.',
    };

    let contents = prefixes[cmd] || query;
    if (cmd === 'حلل' && imgMsg) {
      const stream = await ctx.downloadContentFromMessage(imgMsg, 'image');
      const chunks = [];
      for await (const c of stream) chunks.push(c);
      const b64 = Buffer.concat(chunks).toString('base64');
      contents = {
        parts: [
          { inlineData: { mimeType: imgMsg.mimetype || 'image/jpeg', data: b64 } },
          { text: prefixes['حلل'] },
        ],
      };
    } else if (cmd === 'اسأل') {
      const prev = aiHistory.get(senderJid) || [];
      if (prev.length) {
        contents = `سياق المحادثة السابقة:\n${prev.join('\n')}\n\nالسؤال الجديد:\n${query}`;
      }
    }

    const res = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents,
      config: {
        systemInstruction: 'أنت المساعد الذكي لبوت YAHIA DISTROVA POWER BOT. أجب باحترام ودقة وباللغة العربية المنسقة.',
      },
    });
    const text = res.text?.trim();
    if (!text) throw new Error('EMPTY_RESPONSE');

    if (cmd === 'اسأل') {
      const prev = aiHistory.get(senderJid) || [];
      aiHistory.set(senderJid, [...prev, `المستخدم: ${query.slice(0, 250)}`, `المساعد: ${text.slice(0, 350)}`].slice(-8));
    }

    return reply(withChannelFooter(`🤖 *${ctx.config.botName} AI* ⚡\n──── 🐉⚡ ────\n${text}`), '🤖');
  } catch (err) {
    ctx.recordError?.(cmd, err);
    return reply(withChannelFooter('⚠️ تعذر الحصول على رد من الذكاء الاصطناعي حالياً. تحقق من GEMINI_API_KEY واتصال السيرفر.'), '⚠️');
  }
}

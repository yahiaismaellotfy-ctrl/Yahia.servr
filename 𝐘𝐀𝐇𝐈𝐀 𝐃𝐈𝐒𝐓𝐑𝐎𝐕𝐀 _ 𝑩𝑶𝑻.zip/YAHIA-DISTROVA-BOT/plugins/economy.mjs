import { getUser, saveDb } from '../lib/database.mjs';
import { withChannelFooter } from '../lib/menus.mjs';

const SHOP_ITEMS = [
  { id: 'درع', name: '🛡️ درع الحماية', price: 800, desc: 'وسام حماية لملفك الشخصي' },
  { id: 'تاج', name: '👑 تاج النخبة', price: 2500, desc: 'لقب تاج فاخر في قائمتك' },
  { id: 'تنين', name: '🐉 تعويذة التنين', price: 5000, desc: 'أيقونة التنين البنفسجي النادرة' },
];

export async function handleEconomyCommand(ctx) {
  const { msg, senderJid, pushName, cmd, args, reply, db } = ctx;
  const user = getUser(db, senderJid, pushName);
  user.inventory = user.inventory || [];
  user.transactions = user.transactions || [];
  const msgCtx = ctx.getMessageContextInfo(msg);

  const logTx = (note) => {
    user.transactions.push({ ts: Date.now(), note });
    if (user.transactions.length > 20) user.transactions = user.transactions.slice(-20);
  };

  switch (cmd) {
    case 'حساب_بنكي': {
      user.hasBank = true;
      await saveDb();
      return reply(withChannelFooter(`🏦 *حسابك البنكي مفعل بنجاح يا ${pushName}!*\n💵 المحفظة: ${user.wallet}\n🏛️ البنك: ${user.bank}`), '🏦');
    }
    case 'رصيدي': {
      return reply(withChannelFooter([
        `💰 *البيان المالي — ${pushName}* ⚡`,
        `──── 🐉⚡ ────`,
        `💵 *المحفظة:* ${user.wallet} عملة`,
        `🏦 *البنك:* ${user.bank} عملة`,
        `💎 *الإجمالي:* ${(user.wallet || 0) + (user.bank || 0)} عملة`,
      ].join('\n')), '💰');
    }
    case 'ايداع': {
      const amount = args[0] === 'الكل' ? user.wallet : Math.floor(Number(args[0]));
      if (!amount || amount <= 0 || amount > user.wallet) {
        return reply(withChannelFooter(`⚠️ أدخل مبلغاً صالحاً للإيداع (رصيد محفظتك: ${user.wallet}).`), '⚠️');
      }
      user.wallet -= amount;
      user.bank += amount;
      logTx(`إيداع +${amount} في البنك`);
      await saveDb();
      return reply(withChannelFooter(`✅ تم إيداع *${amount}* عملة في البنك. رصيد البنك: *${user.bank}*`), '🏦');
    }
    case 'سحب': {
      const amount = args[0] === 'الكل' ? user.bank : Math.floor(Number(args[0]));
      if (!amount || amount <= 0 || amount > user.bank) {
        return reply(withChannelFooter(`⚠️ أدخل مبلغاً صالحاً للسحب (رصيد البنك: ${user.bank}).`), '⚠️');
      }
      user.bank -= amount;
      user.wallet += amount;
      logTx(`سحب -${amount} من البنك`);
      await saveDb();
      return reply(withChannelFooter(`✅ تم سحب *${amount}* عملة إلى المحفظة. رصيدك الكاش: *${user.wallet}*`), '💵');
    }
    case 'تحويل': {
      const targetJid = msgCtx?.mentionedJid?.[0] || msgCtx?.participant;
      const amount = Math.floor(Number(args.find((a) => /^\d+$/.test(a))));
      if (!targetJid || !amount || amount <= 0 || amount > user.wallet) {
        return reply(withChannelFooter(`💸 الصيغة: ${ctx.prefix}تحويل @منشن المبلغ (رصيد المحفظة: ${user.wallet})`), 'ℹ️');
      }
      const receiver = getUser(db, targetJid, targetJid.split('@')[0]);
      user.wallet -= amount;
      receiver.wallet = (receiver.wallet || 0) + amount;
      logTx(`تحويل ${amount} إلى @${targetJid.split('@')[0]}`);
      await saveDb();
      return reply(withChannelFooter(`✅ تم تحويل *${amount}* عملة إلى @${targetJid.split(':')[0].split('@')[0]} بنجاح.`), '💸', [targetJid]);
    }
    case 'عمل': {
      const now = Date.now();
      const cooldown = 10 * 60 * 1000;
      if (now - (user.lastWork || 0) < cooldown) {
        const left = Math.ceil((cooldown - (now - user.lastWork)) / 60000);
        return reply(withChannelFooter(`⏳ يمكنك العمل مجدداً بعد *${left}* دقيقة.`), '⏳');
      }
      const jobs = ['مبرمج بوتات', 'مصمم جرافيك', 'مهندس شبكات', 'محلل بيانات'];
      const pay = Math.floor(Math.random() * 350) + 200;
      user.lastWork = now;
      user.wallet += pay;
      user.xp += 25;
      logTx(`راتب عمل +${pay}`);
      await saveDb();
      return reply(withChannelFooter(`💼 عملت اليوم في وظيفة *${jobs[Math.floor(Math.random() * jobs.length)]}* وكسبت *+${pay} عملة* و *+25 XP*!`), '💼');
    }
    case 'يومي': {
      const now = Date.now();
      const dayMs = 24 * 60 * 60 * 1000;
      if (now - (user.lastDaily || 0) < dayMs) {
        const hrs = Math.ceil((dayMs - (now - user.lastDaily)) / 3600000);
        return reply(withChannelFooter(`⏳ استلمت مكافأتك اليومية بالفعل. عد بعد *${hrs}* ساعة.`), '⏳');
      }
      user.lastDaily = now;
      user.wallet += 1000;
      user.xp += 50;
      logTx('مكافأة يومية +1000');
      await saveDb();
      return reply(withChannelFooter('🎁 تم استلام المكافأة اليومية: *+1000 عملة* و *+50 XP*!'), '🎁');
    }
    case 'متجر': {
      const lines = SHOP_ITEMS.map((it, i) => `${i + 1}. ${it.name} — *${it.price}* عملة\n   _${it.desc}_`).join('\n');
      return reply(withChannelFooter(`🛒 *متجر الديستروفا:*\n──── 🐉⚡ ────\n${lines}\n\n💡 للشراء: *${ctx.prefix}شراء درع*`), '🛒');
    }
    case 'شراء': {
      const q = args.join(' ').trim();
      const item = SHOP_ITEMS.find((it) => it.id === q || it.name.includes(q)) || SHOP_ITEMS[Number(q) - 1];
      if (!item) return reply(withChannelFooter(`🛒 اختر عنصراً صحيحاً من ${ctx.prefix}متجر`), 'ℹ️');
      if (user.wallet < item.price) return reply(withChannelFooter(`⚠️ رصيد المحفظة لا يكفي (المطلوب ${item.price}).`), '⚠️');
      user.wallet -= item.price;
      user.inventory.push(item.name);
      logTx(`شراء ${item.name} (-${item.price})`);
      await saveDb();
      return reply(withChannelFooter(`✅ تم شراء *${item.name}* وإضافته إلى مخزونك!`), '🛍️');
    }
    case 'مخزون': {
      const list = user.inventory.length ? user.inventory.map((x, i) => `${i + 1}. ${x}`).join('\n') : '🎒 الحقيبة فارغة حالياً.';
      return reply(withChannelFooter(`🎒 *مخزون ${pushName}:*\n──── 🐉⚡ ────\n${list}`), '🎒');
    }
    case 'مهام': {
      return reply(withChannelFooter([
        `📜 *المهام اليومية:*`,
        `──── 🐉⚡ ────`,
        `✦ ${ctx.prefix}يومي — مكافأة 1000 عملة (${user.lastDaily ? 'منفذة/نشطة' : 'متاحة ✅'})`,
        `✦ ${ctx.prefix}عمل — راتب فوري كل 10 دقائق`,
        `✦ الفوز في الألعاب — 100 إلى 300 عملة لكل جولة`,
      ].join('\n')), '📜');
    }
    case 'كلان': {
      db.clans = db.clans || {};
      const sub = args[0];
      const name = args.slice(1).join(' ').trim();
      if (sub === 'إنشاء' && name) {
        if (db.clans[name]) return reply(withChannelFooter('⚠️ يوجد كلان بهذا الاسم بالفعل.'), '⚠️');
        db.clans[name] = { name, leader: senderJid, members: [senderJid], createdAt: Date.now() };
        user.clan = name;
        await saveDb();
        return reply(withChannelFooter(`⚔️ تم تأسيس كلان *${name}* بنجاح!`), '⚔️');
      }
      if (sub === 'انضمام' && name) {
        if (!db.clans[name]) return reply(withChannelFooter('⚠️ الكلان غير موجود.'), '⚠️');
        if (!db.clans[name].members.includes(senderJid)) db.clans[name].members.push(senderJid);
        user.clan = name;
        await saveDb();
        return reply(withChannelFooter(`🛡️ انضممت إلى كلان *${name}* بنجاح!`), '🛡️');
      }
      const myClan = user.clan && db.clans[user.clan];
      if (!myClan) return reply(withChannelFooter(`⚔️ لست منضماً لكلان بعد. استخدم: *${ctx.prefix}كلان إنشاء اسم_الكلان*`), '⚔️');
      return reply(withChannelFooter(`⚔️ *كلان ${myClan.name}:*\n👥 الأعضاء: ${myClan.members.length}`), '⚔️');
    }
    case 'الاغنى': {
      const rich = Object.values(db.users || {})
        .sort((a, b) => ((b.wallet || 0) + (b.bank || 0)) - ((a.wallet || 0) + (a.bank || 0)))
        .slice(0, 10);
      const lines = rich.map((u, i) => `${i + 1}. *${u.name || 'عضو'}* — ${(u.wallet || 0) + (u.bank || 0)} عملة`).join('\n');
      return reply(withChannelFooter(`💎 *قائمة أغنى الأعضاء:*\n──── 🐉⚡ ────\n${lines || 'لا توجد بيانات بعد.'}`), '💎');
    }
    case 'معاملاتي': {
      const txs = (user.transactions || []).slice(-8).reverse();
      const lines = txs.map((t, i) => `${i + 1}. ${t.note}`).join('\n');
      return reply(withChannelFooter(`🧾 *سجل معاملاتك الأخيرة:*\n──── 🐉⚡ ────\n${lines || 'لا توجد معاملات مسجلة بعد.'}`), '🧾');
    }
  }
  return false;
}

import { saveDb } from '../lib/database.mjs';
import { withChannelFooter } from '../lib/menus.mjs';

export async function handleChannelsCommand(ctx) {
  const { sock, chatJid, cmd, query, isOwner, config, db, reply } = ctx;

  switch (cmd) {
    case 'قناه': {
      const ch = ctx.getResolvedChannel?.();
      return reply(withChannelFooter([
        `📡 *القناة الرسمية — ${config.botName}* ⚡`,
        `──── 🐉⚡ ────`,
        `🏷️ *الاسم:* ${ch?.name || config.portalName}`,
        ch?.subscribers ? `👥 *المتابعون:* ${ch.subscribers}` : `✨ *الحالة:* قناة التحديثات الرسمية`,
        `🔗 *الرابط:* ${config.officialChannelUrl}`,
      ].join('\n')), '📡');
    }
    case 'معلومات_قناة': {
      const codeMatch = (query || config.officialChannelUrl).match(/channel\/([A-Za-z0-9_-]+)/i) || [null, query.trim()];
      const code = codeMatch[1];
      if (!code || typeof sock.newsletterMetadata !== 'function') {
        return reply(withChannelFooter('ℹ️ أرسل رابط القناة أو كود الدعوة بعد الأمر.'), 'ℹ️');
      }
      const meta = await sock.newsletterMetadata('invite', code).catch(() => null);
      if (!meta?.id) return reply(withChannelFooter('⚠️ تعذر جلب بيانات القناة. تأكد من صحة الرابط.'), '⚠️');
      return reply(withChannelFooter([
        `📡 *بيانات القناة* ⚡`,
        `──── 🐉⚡ ────`,
        `🏷️ *الاسم:* ${meta.name || meta.thread_metadata?.name || 'غير متاح'}`,
        `👥 *المتابعون:* ${meta.subscribers ?? 'غير ظاهر'}`,
        `🆔 *المعرف:* \`${meta.id}\``,
        meta.description ? `📝 *الوصف:* ${String(meta.description).slice(0, 180)}` : '',
      ].filter(Boolean).join('\n')), '📡');
    }
    case 'نشر_قناة': {
      if (!isOwner) return reply(withChannelFooter('👑 هذا الأمر مخصص لمالك البوت.'), '⚠️');
      if (!query) return reply(withChannelFooter('✏️ اكتب نص المنشور المطلوب نشره في القناة.'), 'ℹ️');
      const ch = ctx.getResolvedChannel?.();
      const targetCh = ch?.jid || config.channelJid;
      await sock.sendMessage(targetCh, { text: withChannelFooter(query) }).catch(async () => {
        await reply(withChannelFooter(`📣 *تم تجهيز منشور القناة:*\n${query}`), '📣');
      });
      await reply(withChannelFooter('✅ تم إرسال المنشور إلى القناة الرسمية.'), '📣');
      return true;
    }
    case 'تفاعل_قناة': {
      const [postUrl, emoji] = query.split(/\s+/);
      if (!postUrl || !emoji) return reply(withChannelFooter(`ℹ️ الصيغة: ${ctx.prefix}تفاعل_قناة رابط_المنشور 🔥`), 'ℹ️');
      const m = postUrl.match(/channel\/([A-Za-z0-9_-]+)\/(\d+)/i);
      if (!m || typeof sock.newsletterReactMessage !== 'function') {
        return reply(withChannelFooter('⚠️ أرسل رابط منشور قناة واتساب صحيح متبوعاً بإيموجي.'), '⚠️');
      }
      const meta = await sock.newsletterMetadata('invite', m[1]).catch(() => null);
      if (!meta?.id) return reply(withChannelFooter('⚠️ لم يتم العثور على القناة.'), '⚠️');
      await sock.newsletterReactMessage(meta.id, m[2], emoji);
      return reply(withChannelFooter(`✅ تم إرسال تفاعل ${emoji} على منشور القناة.`), emoji);
    }
    case 'متابعة_قناة': {
      if (!isOwner) return reply(withChannelFooter('👑 للمالك فقط.'), '⚠️');
      const m = query.match(/channel\/([A-Za-z0-9_-]+)/i);
      if (!m) return reply(withChannelFooter('ℹ️ أرسل رابط القناة الصحيح.'), 'ℹ️');
      const meta = await sock.newsletterMetadata('invite', m[1]).catch(() => null);
      if (!meta?.id || typeof sock.newsletterFollow !== 'function') {
        return reply(withChannelFooter('⚠️ تعذر متابعة القناة.'), '⚠️');
      }
      await sock.newsletterFollow(meta.id);
      return reply(withChannelFooter(`✅ تم اشتراك البوت في قناة *${meta.name || m[1]}* بنجاح.`), '📡');
    }
    case 'استطلاع_قناة': {
      const parts = query.split('|').map((s) => s.trim()).filter(Boolean);
      if (parts.length < 3) return reply(withChannelFooter(`📊 الصيغة: ${ctx.prefix}استطلاع_قناة السؤال | خيار1 | خيار2`), 'ℹ️');
      const [q, ...opts] = parts;
      return reply(withChannelFooter(`📊 *استطلاع جاهز للقناة:*\n❓ *${q}*\n${opts.map((o, i) => `${i + 1}. ${o}`).join('\n')}`), '📊');
    }
    case 'بوست_مجدول': {
      if (!isOwner) return reply(withChannelFooter('👑 للمالك فقط.'), '⚠️');
      const [minsStr, ...rest] = query.split('|');
      const mins = Math.max(1, Math.min(120, Number(minsStr) || 0));
      const postText = rest.join('|').trim();
      if (!mins || !postText) return reply(withChannelFooter(`⏰ الصيغة: ${ctx.prefix}بوست_مجدول 10 | نص المنشور`), 'ℹ️');
      setTimeout(async () => {
        const ch = ctx.getResolvedChannel?.();
        const target = ch?.jid || config.channelJid;
        await sock.sendMessage(target, { text: withChannelFooter(postText) }).catch(() => {
          sock.sendMessage(chatJid, { text: withChannelFooter(`⏰ *منشور مجدول:*\n${postText}`) }).catch(() => {});
        });
      }, mins * 60 * 1000);
      return reply(withChannelFooter(`⏰ تم جدولة المنشور وسيُرسل تلقائياً بعد *${mins}* دقيقة.`), '⏰');
    }
    case 'اعلان_قناة': {
      if (!isOwner) return reply(withChannelFooter('👑 للمالك فقط.'), '⚠️');
      return reply(withChannelFooter([
        `📣 *دعوة للانضمام إلى قناة ${config.botName}* ⚡`,
        `──── 🐉⚡ ────`,
        `✨ تابع أحدث الأوامر والتحديثات الحصرية مباشرة من المطور.`,
        `🔗 ${config.officialChannelUrl}`,
      ].join('\n')), '📣');
    }
  }
  return false;
}

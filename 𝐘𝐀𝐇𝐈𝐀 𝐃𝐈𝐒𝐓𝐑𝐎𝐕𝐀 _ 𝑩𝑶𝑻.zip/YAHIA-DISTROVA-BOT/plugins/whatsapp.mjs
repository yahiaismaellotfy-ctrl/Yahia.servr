import os from 'os';
import { createSubBotPairing } from '../lib/subbot.mjs';
import { formatMainMenu, formatUptime, withChannelFooter } from '../lib/menus.mjs';
import { saveDb } from '../lib/database.mjs';

export async function handleWhatsappToolsCommand(ctx) {
  const { sock, msg, chatJid, senderNum, pushName, cmd, args, query, reply, replyBanner, db, config, startedAt, commandsCount, categoriesCount, prefix } = ctx;

  switch (cmd) {
    case 'اوامر':
    case 'القائمة':
    case 'منيو': {
      const catQuery = cmd === 'اوامر' ? query : '';
      if (catQuery) {
        const catMenu = ctx.formatCategoryMenuByQuery(catQuery, prefix);
        if (catMenu) return reply(catMenu, '📂');
      }
      const groupsCount = Object.keys(await sock.groupFetchAllParticipating().catch(() => ({}))).length || Object.keys(db.groups || {}).length;
      const gData = chatJid.endsWith('@g.us') ? db.groups?.[chatJid] : null;
      const mainText = formatMainMenu({
        senderName: pushName,
        uptimeText: formatUptime(Date.now() - db.stats.startedAt),
        prefix,
        commandsCount,
        categoriesCount,
        connected: Boolean(sock.user?.id),
        antiLinkActive: gData ? Boolean(gData.antiLink) : Boolean(config.features.antiLink),
        welcomeActive: gData ? Boolean(gData.welcome) : Boolean(config.features.welcome),
        aiActive: Boolean(process.env.GEMINI_API_KEY) && (gData ? gData.aiEnabled !== false : true),
        usersCount: Object.keys(db.users || {}).length,
        groupsCount,
        dbConnected: true,
        memMb: (process.memoryUsage().rss / 1024 / 1024).toFixed(1),
      });
      return replyBanner(mainText, '🐉');
    }
    case 'رقمي': {
      return reply(withChannelFooter(`📱 *رقمك المسجل:* +${senderNum}`), '📱');
    }
    case 'رابط_رقمي': {
      return reply(withChannelFooter(`🔗 *رابط المحادثة المباشر لرقمك:*\nhttps://wa.me/${senderNum}`), '🔗');
    }
    case 'منشن': {
      const msgCtx = ctx.getMessageContextInfo(msg);
      const target = msgCtx?.mentionedJid?.[0] || msgCtx?.participant;
      if (!target) return reply(withChannelFooter(`ℹ️ منشن العضو: ${prefix}منشن @عضو رسالتك`), 'ℹ️');
      const note = args.filter((a) => !a.startsWith('@')).join(' ').trim() || 'نداء لك ⚡';
      return reply(withChannelFooter(`📢 @${target.split(':')[0].split('@')[0]} — ${note}`), '📢', [target]);
    }
    case 'وقت': {
      const now = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      return reply(withChannelFooter(`⏰ *الوقت الحالي:* ${now}`), '⏰');
    }
    case 'تاريخ': {
      const greg = new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      const hijri = new Intl.DateTimeFormat('ar-SA-u-ca-islamic', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date());
      return reply(withChannelFooter(`📅 *التاريخ الميلادي:* ${greg}\n🌙 *التاريخ الهجري:* ${hijri}`), '📅');
    }
    case 'سرعة':
    case 'بنق': {
      const pingMs = Math.max(5, Date.now() - startedAt);
      return reply(withChannelFooter(`⚡ *سرعة الاستجابة:* ${pingMs} ms`), '⚡');
    }
    case 'حالة':
    case 'تست': {
      const mem = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
      return reply(withChannelFooter([
        `🤖 *حالة ${config.botName}* ⚡`,
        `──── 🐉⚡ ────`,
        `📡 *الاتصال:* ${sock.user?.id ? 'متصل بنجاح ✅' : 'غير متصل ⚠️'}`,
        `⏱️ *مدة التشغيل:* ${formatUptime(Date.now() - db.stats.startedAt)}`,
        `🔋 *الذاكرة:* ${mem} MB`,
        `⚡ *الأوامر العاملة:* ${commandsCount} أمر (${categoriesCount} قسم)`,
      ].join('\n')), '🤖');
    }
    case 'السيرفر':
    case 'النظام':
    case 'الإحصائيات': {
      const memMb = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
      const totalMemGb = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);
      const load = os.loadavg()[0]?.toFixed(2) || '0.00';
      const groupsCount = Object.keys(await sock.groupFetchAllParticipating().catch(() => ({}))).length || Object.keys(db.groups || {}).length;
      const lastRestart = new Date(db.stats.lastRestartAt || db.stats.startedAt).toLocaleString('ar-EG');
      return reply(withChannelFooter([
        `📊 *لوحة النظام والإحصائيات الحقيقية* ⚡`,
        `──── 🐉⚡ ────`,
        `📡 *اتصال واتساب:* ${sock.user?.id ? 'متصل ✅' : 'متوقف ⚠️'}`,
        `💾 *قاعدة البيانات:* متصلة ✅`,
        `🤖 *الذكاء الاصطناعي:* ${process.env.GEMINI_API_KEY ? 'جاهز ✅' : 'غير مضبوط (GEMINI_API_KEY)'}`,
        `⚡ *الأوامر المسجلة:* ${commandsCount}`,
        `✅ *الأوامر الناجحة:* ${db.stats.totalSuccess || 0}`,
        `❌ *الأخطاء:* ${db.stats.totalErrors || 0}`,
        `👥 *المستخدمون:* ${Object.keys(db.users || {}).length}`,
        `🌐 *المجموعات:* ${groupsCount}`,
        `⏱️ *مدة التشغيل:* ${formatUptime(Date.now() - db.stats.startedAt)}`,
        `🔋 *الذاكرة:* ${memMb} MB / ${totalMemGb} GB`,
        `🖥️ *حمل المعالج:* ${load} | Node ${process.version}`,
        `🔄 *آخر إعادة تشغيل:* ${lastRestart}`,
      ].join('\n')), '📊');
    }
    case 'بوت': {
      const mem = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
      const cardText = [
        `🐉 *${config.portalName}* ⚡`,
        `🤖 *${config.botName} | 𝑷𝑶𝑾𝑬𝑹 𝑩𝑶𝑻* 👨‍💻`,
        `──── 🐉⚡ ────`,
        `👑 *المطور:* ${config.developerBadge || config.developerName}`,
        `👤 *المستخدم:* ${pushName}`,
        `⚡ *الأوامر:* ${commandsCount} أمر حقيقي (${categoriesCount} قسم)`,
        `⏱️ *التشغيل:* ${formatUptime(Date.now() - db.stats.startedAt)}`,
        `🔋 *الرام:* ${mem} MB`,
        `──── 🐉⚡ ────`,
      ].join('\n');

      let sentInteractive = false;
      try {
        if (typeof sock.relayMessage === 'function') {
          const baileysMod = await import('@whiskeysockets/baileys');
          const waProto = baileysMod.proto || baileysMod.default?.proto;
          const interactiveProto = waProto?.Message?.InteractiveMessage;
          if (interactiveProto) {
            const msgContent = {
              viewOnceMessage: {
                message: {
                  messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                  interactiveMessage: interactiveProto.create({
                    body: interactiveProto.Body.create({ text: cardText }),
                    footer: interactiveProto.Footer.create({ text: `👨‍💻 ${config.developerName} • 🐉⚡` }),
                    nativeFlowMessage: interactiveProto.NativeFlowMessage.create({
                      buttons: [
                        {
                          name: 'cta_url',
                          buttonParamsJson: JSON.stringify({
                            display_text: '📡 عرض القناة',
                            url: config.officialChannelUrl,
                            merchant_url: config.officialChannelUrl,
                          }),
                        },
                        {
                          name: 'quick_reply',
                          buttonParamsJson: JSON.stringify({
                            display_text: '📜 أوامر',
                            id: `${prefix}اوامر`,
                          }),
                        },
                      ],
                    }),
                  }),
                },
              },
            };
            for (const flowContent of [
              [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
              [{ tag: 'native_flow', attrs: { name: 'quick_reply' } }],
            ]) {
              try {
                await sock.relayMessage(chatJid, msgContent, {
                  additionalNodes: [{ tag: 'biz', attrs: {}, content: [{ tag: 'interactive', attrs: { type: 'native_flow', v: '1' }, content: flowContent }] }],
                });
                sentInteractive = true;
                break;
              } catch {}
            }
          }
        }
      } catch {}
      if (!sentInteractive) {
        await reply(withChannelFooter(cardText), '🐉');
      }
      return true;
    }
    case 'تنصيب': {
      const targetPhone = (args[0] || '').replace(/\D/g, '');
      if (targetPhone.length < 10) {
        return replyBanner(withChannelFooter(`📡 *التنصيب الفوري:*\nاكتب رقمك بالصيغة الدولية بعد الأمر:\n*${prefix}تنصيب 2010xxxxxxxx*`), '📡');
      }
      await createSubBotPairing(sock, chatJid, msg, targetPhone, ctx.handleIncomingMessage);
      return true;
    }
    case 'ايقاف_التنصيب': {
      const phone = (args[0] || senderNum).replace(/\D/g, '');
      const { stopSubBotByPhone } = await import('../lib/subbot.mjs');
      const stopped = stopSubBotByPhone(phone);
      return reply(withChannelFooter(stopped ? `🛑 تم إيقاف الجلسة الفرعية للرقم ${phone}.` : `ℹ️ لا توجد جلسة فرعية نشطة للرقم ${phone}.`), '🛑');
    }
    case 'المتصلين_تنصيب': {
      const { listSubBots } = await import('../lib/subbot.mjs');
      const list = listSubBots();
      const text = list.length
        ? list.map((b, i) => `${i + 1}. ${b.phone} — ${b.connected ? 'متصل ✅' : 'جاري الربط ⏳'}`).join('\n')
        : '📭 لا توجد جلسات فرعية نشطة حالياً.';
      return reply(withChannelFooter(`📡 *الجلسات الفرعية:*\n──── 🐉⚡ ────\n${text}`), '📡');
    }
  }
  return false;
}

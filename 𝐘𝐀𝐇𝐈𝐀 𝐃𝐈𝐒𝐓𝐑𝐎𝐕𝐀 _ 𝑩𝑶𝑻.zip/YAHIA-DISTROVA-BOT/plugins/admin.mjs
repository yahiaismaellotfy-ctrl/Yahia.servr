import { getGroup, saveDb } from '../lib/database.mjs';
import { withChannelFooter } from '../lib/menus.mjs';

export async function handleAdminCommand(ctx) {
  const { sock, msg, chatJid, isGroup, isAdmin, isOwner, isBotAdmin, groupMeta, cmd, query, args, reply, config, db } = ctx;
  if (!isGroup) {
    return reply(withChannelFooter('⚠️ أوامر إدارة الجروبات تعمل داخل المجموعات فقط.'), '⚠️');
  }

  const groupData = getGroup(db, chatJid);
  const msgCtx = ctx.getMessageContextInfo(msg);
  const rawTarget = msgCtx?.mentionedJid?.[0] || msgCtx?.participant || '';
  const resolveTargetJid = () => {
    if (!rawTarget) return '';
    const rawId = rawTarget.split(':')[0].split('@')[0];
    const match = groupMeta?.participants?.find((p) => {
      const pId = (p.id || '').split(':')[0].split('@')[0];
      const pPhone = (p.phoneNumber || '').split(':')[0].split('@')[0];
      return pId === rawId || pPhone === rawId;
    });
    return match?.id || rawTarget;
  };
  const targetJid = resolveTargetJid();
  const targetNum = targetJid.split(':')[0].split('@')[0];

  const requireAdminAndBot = async (needsBotAdmin = true) => {
    if (!isAdmin && !isOwner) {
      await reply(withChannelFooter('🛡️ هذا الأمر متاح لمشرفي المجموعة فقط.'), '⚠️');
      return false;
    }
    if (needsBotAdmin && !isBotAdmin) {
      await reply(withChannelFooter('⚠️ يجب ترقية البوت إلى مشرف (Admin) أولاً لتنفيذ هذا الأمر.'), '⚠️');
      return false;
    }
    return true;
  };

  switch (cmd) {
    case 'طرد': {
      if (!(await requireAdminAndBot(true))) return true;
      if (!targetJid) return reply(withChannelFooter('ℹ️ منشن العضو أو رد على رسالته مع الأمر.'), 'ℹ️');
      await sock.groupParticipantsUpdate(chatJid, [targetJid], 'remove');
      await reply(withChannelFooter(`🚫 تم طرد العضو @${targetNum} من المجموعة بنجاح.`), '🚫', [targetJid]);
      return true;
    }
    case 'ترقية': {
      if (!(await requireAdminAndBot(true))) return true;
      if (!targetJid) return reply(withChannelFooter('ℹ️ منشن العضو أو رد على رسالته للترقية.'), 'ℹ️');
      await sock.groupParticipantsUpdate(chatJid, [targetJid], 'promote');
      await reply(withChannelFooter(`👑 تم ترقية @${targetNum} إلى مشرف في المجموعة.`), '👑', [targetJid]);
      return true;
    }
    case 'تنزيل': {
      if (!(await requireAdminAndBot(true))) return true;
      if (!targetJid) return reply(withChannelFooter('ℹ️ منشن المشرف أو رد على رسالته لتنزيله.'), 'ℹ️');
      await sock.groupParticipantsUpdate(chatJid, [targetJid], 'demote');
      await reply(withChannelFooter(`⬇️ تم تنزيل @${targetNum} من الإشراف بنجاح.`), '⬇️', [targetJid]);
      return true;
    }
    case 'قفل': {
      if (!(await requireAdminAndBot(true))) return true;
      await sock.groupSettingUpdate(chatJid, 'announcement');
      await reply(withChannelFooter('🔒 تم قفل المجموعة — الإرسال متاح للمشرفين فقط.'), '🔒');
      return true;
    }
    case 'فتح': {
      if (!(await requireAdminAndBot(true))) return true;
      await sock.groupSettingUpdate(chatJid, 'not_announcement');
      await reply(withChannelFooter('🔓 تم فتح المجموعة — الإرسال متاح لجميع الأعضاء.'), '🔓');
      return true;
    }
    case 'منشن_الكل': {
      if (!(await requireAdminAndBot(false))) return true;
      const members = (groupMeta?.participants || []).map((p) => p.id);
      const header = query || 'نداء عام لجميع أعضاء المجموعة';
      const bodyText = `📢 *${header}*\n──── 🐉⚡ ────\n\n` +
        members.map((m) => `✦ @${m.split(':')[0].split('@')[0]}`).join('\n');
      await reply(withChannelFooter(bodyText), '📢', members);
      return true;
    }
    case 'مخفي': {
      if (!(await requireAdminAndBot(false))) return true;
      const members = (groupMeta?.participants || []).map((p) => p.id);
      const header = query || 'إشعار هام لجميع الأعضاء ⚡';
      await sock.sendMessage(chatJid, { text: header, mentions: members });
      return true;
    }
    case 'مشرفين': {
      const admins = (groupMeta?.participants || []).filter((p) => p.admin);
      const list = admins.map((a, i) => `${i + 1}. @${a.id.split(':')[0].split('@')[0]} (${a.admin === 'superadmin' ? 'المؤسس 👑' : 'مشرف 🛡️'})`).join('\n');
      await reply(withChannelFooter(`🛡️ *قائمة مشرفي ${groupMeta?.subject || 'المجموعة'} (${admins.length}):*\n──── 🐉⚡ ────\n${list || 'لا يوجد'}`), '🛡️', admins.map((a) => a.id));
      return true;
    }
    case 'معلومات_الجروب': {
      const total = groupMeta?.participants?.length || 0;
      const admins = (groupMeta?.participants || []).filter((p) => p.admin).length;
      await reply(withChannelFooter([
        `🏰 *معلومات المجموعة* ⚡`,
        `──── 🐉⚡ ────`,
        `📛 *الاسم:* ${groupMeta?.subject || 'غير متاح'}`,
        `👥 *الأعضاء:* ${total} عضو (${admins} مشرف)`,
        `🛡️ *مضاد الروابط:* ${groupData.antiLink ? 'نشط ✅' : 'متوقف ⚠️'}`,
        `🛡️ *مضاد السبام:* ${groupData.antiSpam ? 'نشط ✅' : 'متوقف ⚠️'}`,
        `💬 *الترحيب:* ${groupData.welcome ? 'نشط ✅' : 'متوقف ⚠️'}`,
        `🤖 *الذكاء الاصطناعي:* ${groupData.aiEnabled !== false ? 'نشط ✅' : 'متوقف ⚠️'}`,
        groupMeta?.desc ? `📝 *الوصف:* ${String(groupMeta.desc).slice(0, 200)}` : '',
      ].filter(Boolean).join('\n')), '🏰');
      return true;
    }
    case 'اسم_الجروب': {
      if (!(await requireAdminAndBot(true))) return true;
      if (!query) return reply(withChannelFooter('✏️ اكتب الاسم الجديد للمجموعة بعد الأمر.'), 'ℹ️');
      await sock.groupUpdateSubject(chatJid, query.slice(0, 100));
      await reply(withChannelFooter(`✅ تم تغيير اسم المجموعة إلى: *${query.slice(0, 100)}*`), '✅');
      return true;
    }
    case 'وصف_الجروب': {
      if (!(await requireAdminAndBot(true))) return true;
      if (!query) return reply(withChannelFooter('✏️ اكتب الوصف الجديد للمجموعة بعد الأمر.'), 'ℹ️');
      await sock.groupUpdateDescription(chatJid, query.slice(0, 512));
      await reply(withChannelFooter('✅ تم تحديث وصف المجموعة بنجاح.'), '✅');
      return true;
    }
    case 'وصف': {
      await reply(withChannelFooter(`📝 *وصف المجموعة:*\n──── 🐉⚡ ────\n${groupMeta?.desc || 'لا يوجد وصف مسجل لهذه المجموعة.'}`), '📝');
      return true;
    }
    case 'تغيير_صورة_الجروب': {
      if (!(await requireAdminAndBot(true))) return true;
      const quoted = msgCtx?.quotedMessage;
      const imgMsg = quoted?.imageMessage || ctx.unwrapMessageContent(msg.message)?.imageMessage;
      if (!imgMsg) return reply(withChannelFooter('📸 أرسل صورة أو رد على صورة بالأمر لتغيير أيقونة المجموعة.'), 'ℹ️');
      const stream = await ctx.downloadContentFromMessage(imgMsg, 'image');
      const chunks = [];
      for await (const c of stream) chunks.push(c);
      await sock.updateProfilePicture(chatJid, Buffer.concat(chunks));
      await reply(withChannelFooter('✅ تم تحديث صورة المجموعة بنجاح.'), '📸');
      return true;
    }
    case 'صورة_الجروب': {
      const url = await sock.profilePictureUrl(chatJid, 'image').catch(() => '');
      if (!url) return reply(withChannelFooter('🖼️ لا توجد صورة مخصصة لهذه المجموعة أو تم إخفاؤها.'), 'ℹ️');
      await sock.sendMessage(chatJid, { image: { url }, caption: withChannelFooter(`🖼️ *صورة مجموعة:* ${groupMeta?.subject || ''}`) });
      return true;
    }
    case 'رابط': {
      if (!(await requireAdminAndBot(true))) return true;
      const code = await sock.groupInviteCode(chatJid);
      await reply(withChannelFooter(`🔗 *رابط المجموعة:*\nhttps://chat.whatsapp.com/${code}`), '🔗');
      return true;
    }
    case 'تجديد_الرابط': {
      if (!(await requireAdminAndBot(true))) return true;
      const code = await sock.groupRevokeInvite(chatJid);
      await reply(withChannelFooter(`🔄 *تم تجديد رابط الدعوة:*\nhttps://chat.whatsapp.com/${code}`), '🔄');
      return true;
    }
    case 'تثبيت':
    case 'الغاء_تثبيت': {
      if (!(await requireAdminAndBot(true))) return true;
      if (!msgCtx?.stanzaId) return reply(withChannelFooter('📌 رد على الرسالة المطلوبة لتنفيذ الأمر.'), 'ℹ️');
      await sock.sendMessage(chatJid, {
        pin: {
          remoteJid: chatJid,
          fromMe: msgCtx.participant === sock.user?.id,
          id: msgCtx.stanzaId,
          participant: msgCtx.participant,
        },
        type: cmd === 'تثبيت' ? 1 : 0,
      }).catch(() => {});
      await reply(withChannelFooter(cmd === 'تثبيت' ? '📌 تم إرسال أمر تثبيت الرسالة.' : '📌 تم إلغاء تثبيت الرسالة.'), '📌');
      return true;
    }
    case 'حذف': {
      if (!(await requireAdminAndBot(true))) return true;
      if (!msgCtx?.stanzaId) return reply(withChannelFooter('🗑️ رد على الرسالة المراد حذفها.'), 'ℹ️');
      await sock.sendMessage(chatJid, {
        delete: {
          remoteJid: chatJid,
          fromMe: false,
          id: msgCtx.stanzaId,
          participant: msgCtx.participant,
        },
      });
      return true;
    }
    case 'كتم': {
      if (!(await requireAdminAndBot(true))) return true;
      if (!targetJid) return reply(withChannelFooter('ℹ️ منشن العضو لكتمه.'), 'ℹ️');
      if (!groupData.muted.includes(targetJid)) groupData.muted.push(targetJid);
      await saveDb();
      await reply(withChannelFooter(`🔇 تم كتم @${targetNum} — سيتم حذف رسائله تلقائياً.`), '🔇', [targetJid]);
      return true;
    }
    case 'فك_كتم': {
      if (!(await requireAdminAndBot(false))) return true;
      if (!targetJid) return reply(withChannelFooter('ℹ️ منشن العضو لفك الكتم عنه.'), 'ℹ️');
      groupData.muted = groupData.muted.filter((id) => id !== targetJid);
      await saveDb();
      await reply(withChannelFooter(`🔊 تم فك الكتم عن @${targetNum}.`), '🔊', [targetJid]);
      return true;
    }
    case 'قوانين': {
      await reply(withChannelFooter(`📜 *قوانين ${groupMeta?.subject || 'المجموعة'}:*\n──── 🐉⚡ ────\n${groupData.rules}`), '📜');
      return true;
    }
    case 'ضع_قوانين': {
      if (!(await requireAdminAndBot(false))) return true;
      if (!query) return reply(withChannelFooter('✏️ اكتب نص القوانين الجديد بعد الأمر.'), 'ℹ️');
      groupData.rules = query;
      await saveDb();
      await reply(withChannelFooter('✅ تم حفظ قوانين المجموعة الجديدة بنجاح.'), '✅');
      return true;
    }
    case 'تصويت': {
      if (!(await requireAdminAndBot(false))) return true;
      const parts = query.split('|').map((s) => s.trim()).filter(Boolean);
      if (parts.length < 3) {
        return reply(withChannelFooter(`📊 اكتب: ${ctx.prefix}تصويت السؤال | خيار1 | خيار2`), 'ℹ️');
      }
      const [name, ...values] = parts;
      await sock.sendMessage(chatJid, { poll: { name, values: values.slice(0, 12), selectableCount: 1 } });
      return true;
    }
    case 'طلبات_الانضمام': {
      if (!(await requireAdminAndBot(true))) return true;
      const list = typeof sock.groupRequestParticipantsList === 'function'
        ? await sock.groupRequestParticipantsList(chatJid).catch(() => [])
        : [];
      if (!list.length) return reply(withChannelFooter('📭 لا توجد طلبات انضمام معلقة حالياً.'), '📭');
      const action = args[0] === 'قبول' ? 'approve' : args[0] === 'رفض' ? 'reject' : null;
      if (action && typeof sock.groupRequestParticipantsUpdate === 'function') {
        await sock.groupRequestParticipantsUpdate(chatJid, list.map((x) => x.jid), action);
        await reply(withChannelFooter(`✅ تم ${action === 'approve' ? 'قبول' : 'رفض'} ${list.length} طلب انضمام.`), '✅');
        return true;
      }
      const lines = list.slice(0, 20).map((x, i) => `${i + 1}. @${x.jid.split('@')[0]}`).join('\n');
      await reply(withChannelFooter(`📥 *طلبات الانضمام (${list.length}):*\n${lines}\n\n💡 للقبول اكتب: ${ctx.prefix}طلبات_الانضمام قبول`), '📥', list.map((x) => x.jid));
      return true;
    }
    case 'أعضاء': {
      const total = groupMeta?.participants?.length || 0;
      const admins = (groupMeta?.participants || []).filter((p) => p.admin).length;
      await reply(withChannelFooter(`👥 *إحصاء أعضاء ${groupMeta?.subject || 'المجموعة'}:*\n✦ الإجمالي: *${total}* عضو\n✦ المشرفون: *${admins}*\n✦ الأعضاء: *${Math.max(0, total - admins)}*`), '👥');
      return true;
    }
    case 'نشيطين': {
      const ranked = Object.values(db.users || {})
        .filter((u) => (u.groupMessages?.[chatJid] || u.messages || 0) > 0)
        .sort((a, b) => (b.groupMessages?.[chatJid] || b.messages || 0) - (a.groupMessages?.[chatJid] || a.messages || 0))
        .slice(0, 10);
      const lines = ranked.map((u, i) => `${i + 1}. *${u.name || 'عضو'}* — ${u.groupMessages?.[chatJid] || u.messages || 0} رسالة`).join('\n');
      await reply(withChannelFooter(`🔥 *أكثر الأعضاء نشاطاً:*\n──── 🐉⚡ ────\n${lines || 'لا توجد بيانات تفاعل بعد.'}`), '🔥');
      return true;
    }
    case 'غير_نشيطين': {
      if (!(await requireAdminAndBot(false))) return true;
      const inactive = (groupMeta?.participants || []).filter((p) => {
        const u = db.users?.[p.id];
        return !u || (u.groupMessages?.[chatJid] || 0) === 0;
      });
      const sample = inactive.slice(0, 20).map((p, i) => `${i + 1}. @${p.id.split(':')[0].split('@')[0]}`).join('\n');
      await reply(withChannelFooter(`💤 *الأعضاء غير النشطين (${inactive.length}):*\n──── 🐉⚡ ────\n${sample || 'الجميع متفاعلون ✅'}`), '💤', inactive.slice(0, 20).map((p) => p.id));
      return true;
    }
  }
  return false;
}

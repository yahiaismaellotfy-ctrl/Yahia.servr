import QRCode from 'qrcode';
import { buildFancyStyles } from './stickers.mjs';
import { withChannelFooter } from '../lib/menus.mjs';

export async function handleUtilitiesCommand(ctx) {
  const { sock, msg, chatJid, cmd, args, query, reply } = ctx;

  switch (cmd) {
    case 'زخرفة': {
      const target = query || ctx.pushName;
      const list = buildFancyStyles(target).map((s, i) => `${i + 1}. ${s}`).join('\n');
      return reply(withChannelFooter(`🎨 *زخرفة الاسم — ${target}:*\n──── 🐉⚡ ────\n${list}`), '🎨');
    }
    case 'اختصار_رابط': {
      if (!/^https?:\/\//i.test(query)) return reply(withChannelFooter('🔗 أدخل رابطاً يبدأ بـ http:// أو https://'), 'ℹ️');
      const short = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(query)}`, { signal: AbortSignal.timeout(7000) }).then((r) => r.text()).catch(() => '');
      if (!short.startsWith('http')) return reply(withChannelFooter('⚠️ تعذر اختصار الرابط حالياً.'), '⚠️');
      return reply(withChannelFooter(`🔗 *الرابط المختصر:* ${short}`), '🔗');
    }
    case 'باركود': {
      if (!query) return reply(withChannelFooter('📲 اكتب النص أو الرابط لتحويله إلى QR Code.'), 'ℹ️');
      const buf = await QRCode.toBuffer(query, { width: 512, margin: 2 });
      await sock.sendMessage(chatJid, { image: buf, caption: withChannelFooter(`📲 *تم توليد QR لـ:* ${query.slice(0, 80)}`) });
      return true;
    }
    case 'قراءة_باركود': {
      const msgCtx = ctx.getMessageContextInfo(msg);
      const imgMsg = ctx.unwrapMessageContent(msgCtx?.quotedMessage || msg.message)?.imageMessage;
      if (!imgMsg) return reply(withChannelFooter('📲 رد على صورة رمز QR Code لقراءتها.'), 'ℹ️');
      return reply(withChannelFooter('📲 تم استلام صورة الـ QR — إذا كانت تحتوي على رابط يمكن قراءتها عبر واجهة الذكاء الاصطناعي (.حلل).'), '📲');
    }
    case 'حساب_العمر': {
      const d = new Date(query);
      if (!query || Number.isNaN(d.getTime())) return reply(withChannelFooter(`🎂 اكتب تاريخ ميلادك بصيغة YYYY-MM-DD (مثال: ${ctx.prefix}حساب_العمر 2004-05-15)`), 'ℹ️');
      const now = new Date();
      let years = now.getFullYear() - d.getFullYear();
      let months = now.getMonth() - d.getMonth();
      let days = now.getDate() - d.getDate();
      if (days < 0) { months -= 1; days += 30; }
      if (months < 0) { years -= 1; months += 12; }
      return reply(withChannelFooter(`🎂 *عمرك الدقيق:* *${years}* سنة و *${months}* شهر و *${days}* يوم.`), '🎂');
    }
    case 'حساب': {
      if (!query || !/^[0-9+\-*/().\s]+$/.test(query)) {
        return reply(withChannelFooter(`🧮 أدخل معادلة أرقام صحيحة فقط (مثال: ${ctx.prefix}حساب (15 * 4) + 10)`), '⚠️');
      }
      const result = Function(`'use strict'; return (${query})`)();
      return reply(withChannelFooter(`🧮 *${query} = ${result}*`), '🧮');
    }
    case 'معلومات_هاتف': {
      if (!query) return reply(withChannelFooter('📱 اكتب اسم الهاتف بعد الأمر.'), 'ℹ️');
      return reply(withChannelFooter(`📱 *بحث مواصفات الهاتف (${query}):*\n🔎 https://www.gsmarena.com/results.php3?sQuickSearch=yes&sName=${encodeURIComponent(query)}`), '📱');
    }
    case 'طقس': {
      const city = (query || 'Cairo').trim();
      const geo = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`, { signal: AbortSignal.timeout(7000) }).then((r) => r.json()).catch(() => null);
      const loc = geo?.results?.[0];
      if (!loc) return reply(withChannelFooter('⚠️ لم يتم العثور على المدينة.'), '⚠️');
      const wx = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,relative_humidity_2m,wind_speed_10m`, { signal: AbortSignal.timeout(7000) }).then((r) => r.json()).catch(() => null);
      const cur = wx?.current;
      if (!cur) return reply(withChannelFooter('⚠️ تعذر جلب بيانات الطقس الآن.'), '⚠️');
      return reply(withChannelFooter(`🌤️ *الطقس في ${loc.name}:*\n🌡️ الحرارة: ${cur.temperature_2m}°C\n💧 الرطوبة: ${cur.relative_humidity_2m}%\n💨 الرياح: ${cur.wind_speed_10m} km/h`), '🌤️');
    }
    case 'سرعة_انترنت': {
      const t0 = Date.now();
      await fetch('https://www.google.com/generate_204', { signal: AbortSignal.timeout(5000) }).catch(() => null);
      const ms = Date.now() - t0;
      return reply(withChannelFooter(`🌐 *فحص اتصال الخادم:* استجابة خلال *${ms} ms* ✅`), '🌐');
    }
    case 'تحويل_وحدات': {
      const val = Number(args[0]);
      const from = (args[1] || '').toLowerCase();
      const to = (args[2] || '').toLowerCase();
      if (Number.isNaN(val) || !from || !to) return reply(withChannelFooter(`📏 الصيغة: ${ctx.prefix}تحويل_وحدات 10 km m`), 'ℹ️');
      const table = { 'km->m': (x) => x * 1000, 'm->km': (x) => x / 1000, 'kg->g': (x) => x * 1000, 'g->kg': (x) => x / 1000, 'c->f': (x) => (x * 9) / 5 + 32, 'f->c': (x) => ((x - 32) * 5) / 9 };
      const fn = table[`${from}->${to}`];
      if (!fn) return reply(withChannelFooter('⚠️ التحويلات المتاحة: km/m, kg/g, c/f'), '⚠️');
      return reply(withChannelFooter(`📏 *${val} ${from} = ${Number(fn(val).toFixed(4))} ${to}*`), '📏');
    }
    case 'نكتة': {
      const jokes = [
        'مبرمج راح ينام حط كوبايتين جنب السرير: واحدة مليانة لو عطش، والتانية فاضية لو معطشش! 😄',
        'واحد سأل الذكاء الاصطناعي: إيه سر النجاح؟ قاله: انام بدري... فقفل التليفون وكمل سهر! 😂',
        'معلم رياضيات خلف ولدين، سمى الأول سين والتاني ص، وسأل فين المجهول؟ 😅',
      ];
      return reply(withChannelFooter(`😄 ${jokes[Math.floor(Math.random() * jokes.length)]}`), '😄');
    }
  }
  return false;
}

import { withChannelFooter } from '../lib/menus.mjs';

const MAX_MEDIA_BYTES = 25 * 1024 * 1024;

export async function handleMediaCommand(ctx) {
  const { sock, msg, chatJid, cmd, query, reply } = ctx;
  if (!query && !['استخراج_صوت'].includes(cmd)) {
    return reply(withChannelFooter(`ℹ️ اكتب اسم البحث أو الرابط بعد الأمر: *${ctx.prefix}${cmd} كلمة البحث*`), 'ℹ️');
  }

  try {
    if (cmd === 'انمي') {
      const res = await fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(query)}&limit=1`, { signal: AbortSignal.timeout(8000) });
      const data = await res.json();
      const a = data?.data?.[0];
      if (!a) return reply(withChannelFooter('⚠️ لم يتم العثور على هذا الأنمي.'), '⚠️');
      const caption = withChannelFooter([
        `🎌 *${a.title}* ⚡`,
        `──── 🐉⚡ ────`,
        `⭐ *التقييم:* ${a.score || 'غير محدد'} | 📺 *الحلقات:* ${a.episodes || '?'}`,
        `📌 *الحالة:* ${a.status || 'غير محدد'}`,
        `🔗 ${a.url}`,
      ].join('\n'));
      if (a.images?.jpg?.image_url) {
        await sock.sendMessage(chatJid, { image: { url: a.images.jpg.image_url }, caption });
        return true;
      }
      return reply(caption, '🎌');
    }

    if (cmd === 'شخصية_انمي') {
      const res = await fetch(`https://api.jikan.moe/v4/characters?q=${encodeURIComponent(query)}&limit=1`, { signal: AbortSignal.timeout(8000) });
      const data = await res.json();
      const ch = data?.data?.[0];
      if (!ch) return reply(withChannelFooter('⚠️ لم يتم العثور على الشخصية.'), '⚠️');
      const caption = withChannelFooter(`🎭 *${ch.name}*\n❤️ المفضلات: ${ch.favorites || 0}\n🔗 ${ch.url}`);
      if (ch.images?.jpg?.image_url) {
        await sock.sendMessage(chatJid, { image: { url: ch.images.jpg.image_url }, caption });
        return true;
      }
      return reply(caption, '🎭');
    }

    if (cmd === 'بحث_اغاني' || cmd === 'تحميل_صوت') {
      const res = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(query)}&media=music&limit=3`, { signal: AbortSignal.timeout(8000) });
      const data = await res.json();
      const tracks = data?.results || [];
      if (!tracks.length) return reply(withChannelFooter('🎵 لم يتم العثور على نتائج مطابقة.'), '⚠️');
      const first = tracks[0];
      if (cmd === 'تحميل_صوت' && first.previewUrl) {
        await sock.sendMessage(chatJid, { audio: { url: first.previewUrl }, mimetype: 'audio/mp4' });
      }
      const list = tracks.map((t, i) => `${i + 1}. *${t.trackName}* — ${t.artistName}`).join('\n');
      return reply(withChannelFooter(`🎵 *نتائج الصوتيات:*\n──── 🐉⚡ ────\n${list}`), '🎵');
    }

    if (cmd === 'بحث_تطبيق') {
      const res = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(query)}&entity=software&limit=3`, { signal: AbortSignal.timeout(8000) });
      const data = await res.json();
      const apps = data?.results || [];
      if (!apps.length) return reply(withChannelFooter('📱 لم يتم العثور على التطبيق.'), '⚠️');
      const lines = apps.map((a, i) => `${i + 1}. *${a.trackName}* (⭐ ${a.averageUserRating?.toFixed(1) || 'N/A'})\n   🔗 ${a.trackViewUrl}`).join('\n');
      return reply(withChannelFooter(`📱 *نتائج التطبيقات:*\n──── 🐉⚡ ────\n${lines}`), '📱');
    }

    if (cmd === 'معلومات_فيديو' || cmd === 'بحث_فيديو' || cmd === 'تحميل_فيديو') {
      if (/^https?:\/\//i.test(query)) {
        const oembed = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(query)}`, { signal: AbortSignal.timeout(8000) }).then((r) => r.json()).catch(() => null);
        if (oembed?.title) {
          return reply(withChannelFooter(`🎬 *بيانات الفيديو:*\n📌 *العنوان:* ${oembed.title}\n👤 *القناة/الناشر:* ${oembed.author_name || 'غير متاح'}\n🔗 ${query}`), '🎬');
        }
        const head = await fetch(query, { method: 'HEAD', signal: AbortSignal.timeout(6000) }).catch(() => null);
        const len = Number(head?.headers?.get('content-length') || 0);
        if (len > MAX_MEDIA_BYTES) {
          return reply(withChannelFooter(`⚠️ حجم الملف (${(len / 1024 / 1024).toFixed(1)} MB) يتجاوز الحد الأقصى المسموح به (25 MB).`), '⚠️');
        }
        if (cmd === 'تحميل_فيديو' && head?.ok && (head.headers.get('content-type') || '').includes('video')) {
          await sock.sendMessage(chatJid, { video: { url: query }, caption: withChannelFooter('✅ تم جلب الفيديو بنجاح.') });
          return true;
        }
        return reply(withChannelFooter(`🎬 *الرابط:* ${query}\n📦 *الحجم:* ${len ? (len / 1024 / 1024).toFixed(2) + ' MB' : 'بث/صفحة ويب'}`), '🎬');
      }
      return reply(withChannelFooter(`🔎 *نتيجة البحث السريع:*\n🎬 https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`), '🔎');
    }

    if (cmd === 'بحث_صور' || cmd === 'خلفيات') {
      const url = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrnamespace=6&gsrlimit=3&prop=imageinfo&iiprop=url&format=json`;
      const res = await fetch(url, { signal: AbortSignal.timeout(8000) }).then((r) => r.json()).catch(() => null);
      const pages = Object.values(res?.query?.pages || {});
      const imgUrl = pages.map((p) => p?.imageinfo?.[0]?.url).find((u) => u && /\.(jpg|jpeg|png)$/i.test(u));
      if (imgUrl) {
        await sock.sendMessage(chatJid, { image: { url: imgUrl }, caption: withChannelFooter(`🖼️ *نتيجة الصور:* ${query}`) });
        return true;
      }
      return reply(withChannelFooter(`🖼️ رابط البحث عن الصور: https://unsplash.com/s/photos/${encodeURIComponent(query)}`), '🖼️');
    }

    if (cmd === 'استخراج_صوت') {
      const msgCtx = ctx.getMessageContextInfo(msg);
      const vid = msgCtx?.quotedMessage?.videoMessage || ctx.unwrapMessageContent(msg.message)?.videoMessage;
      if (!vid) return reply(withChannelFooter('🎬 رد على مقطع فيديو لاستخراج الصوت منه.'), 'ℹ️');
      const stream = await ctx.downloadContentFromMessage(vid, 'video');
      const chunks = [];
      for await (const c of stream) chunks.push(c);
      const buf = Buffer.concat(chunks);
      if (buf.length > MAX_MEDIA_BYTES) return reply(withChannelFooter('⚠️ حجم الفيديو أكبر من الحد المسموح به (25 MB).'), '⚠️');
      await sock.sendMessage(chatJid, { audio: buf, mimetype: 'audio/mp4' });
      return true;
    }
  } catch {
    return reply(withChannelFooter('⚠️ تعذر إتمام طلب الميديا حالياً. تحقق من الرابط أو اتصالك وحاول مجدداً.'), '⚠️');
  }
  return false;
}

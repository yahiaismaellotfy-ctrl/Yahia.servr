import { getGroup, getUser, saveDb } from '../lib/database.mjs';
import { withChannelFooter } from '../lib/menus.mjs';

function parseToggle(arg) {
  const v = String(arg || '').trim().toLowerCase();
  if (['تشغيل', 'تفعيل', 'on', 'enable', '1'].includes(v)) return true;
  if (['ايقاف', 'إيقاف', 'تعطيل', 'off', 'disable', '0'].includes(v)) return false;
  return null;
}

export async function handleSecurityCommand(ctx) {
  const { isGroup, isAdmin, isOwner, msg, chatJid, cmd, args, reply, db, groupMeta } = ctx;
  const msgCtx = ctx.getMessageContextInfo(msg);
  const targetJid = msgCtx?.mentionedJid?.[0] || msgCtx?.participant || ctx.senderJid;
  const targetNum = targetJid.split(':')[0].split('@')[0];

  const toggleMap = {
    'انتي_لينك': ['antiLink', 'مضاد روابط الجروبات والمواقع'],
    'مضاد_الروابط': ['antiLink', 'مضاد روابط الجروبات والمواقع'],
    'انتي_قنوات': ['antiChannel', 'مضاد روابط القنوات'],
    'انتي_سبام': ['antiSpam', 'مضاد السبام والرسائل السريعة'],
    'مضاد_الاسبام': ['antiSpam', 'مضاد السبام والرسائل السريعة'],
    'انتي_تكرار': ['antiRepeat', 'مضاد تكرار الرسائل'],
    'انتي_تخريب': ['antiRaid', 'مضاد التخريب وسحب المشرفين'],
    'انتي_اعلانات': ['antiAds', 'منع الإعلانات غير المصرح بها'],
    'انتي_ازعاج': ['antiFlood', 'الحماية من الرسائل المزعجة والطويلة'],
  };

  if (cmd === 'انتي_مكالمات') {
    if (!isOwner) return reply(withChannelFooter('👑 هذا الإعداد خاص بمالك البوت فقط.'), '⚠️');
    const state = parseToggle(args[0]);
    if (state !== null) {
      db.settings.antiCall = state;
      await saveDb();
    }
    const active = db.settings.antiCall;
    return reply(withChannelFooter(`📵 *مضاد المكالمات:* ${active ? 'مفعّل ✅ (يتم رفض المكالمات تلقائياً)' : 'متوقف ⚠️'}`), '🛡️');
  }

  if (!isGroup) {
    return reply(withChannelFooter('⚠️ أوامر حماية المجموعات تعمل داخل الجروبات فقط.'), '⚠️');
  }

  const groupData = getGroup(db, chatJid);

  if (toggleMap[cmd]) {
    if (!isAdmin && !isOwner) return reply(withChannelFooter('🛡️ تغيير إعدادات الحماية متاح للمشرفين فقط.'), '⚠️');
    const [key, label] = toggleMap[cmd];
    const next = parseToggle(args[0]);
    if (next !== null) {
      groupData[key] = next;
      groupData.auditLog = (groupData.auditLog || []).slice(-29);
      groupData.auditLog.push({ ts: Date.now(), action: `${label}: ${next ? 'تشغيل' : 'إيقاف'}`, by: ctx.senderNum });
      await saveDb();
    }
    return reply(withChannelFooter([
      `🛡️ *${label}* ⚡`,
      `──── 🐉⚡ ────`,
      `📌 *الحالة في ${groupMeta?.subject || 'المجموعة'}:* ${groupData[key] ? 'نشط ومفعّل ✅' : 'متوقف ⚠️'}`,
      `💡 للتبديل: ${ctx.prefix}${cmd} تشغيل أو ${ctx.prefix}${cmd} ايقاف`,
    ].join('\n')), '🛡️');
  }

  switch (cmd) {
    case 'تحذير': {
      if (!isAdmin && !isOwner) return reply(withChannelFooter('🛡️ توجيه التحذيرات للمشرفين فقط.'), '⚠️');
      if (!msgCtx?.mentionedJid?.[0] && !msgCtx?.participant) {
        return reply(withChannelFooter('ℹ️ منشن العضو أو رد على رسالته لتوجيه تحذير.'), 'ℹ️');
      }
      const user = getUser(db, targetJid, targetNum);
      user.warns[chatJid] = (user.warns[chatJid] || 0) + 1;
      const reason = args.filter((a) => !a.startsWith('@')).join(' ').trim() || 'مخالفة قوانين المجموعة';
      groupData.auditLog = (groupData.auditLog || []).slice(-29);
      groupData.auditLog.push({ ts: Date.now(), action: `تحذير @${targetNum}: ${reason}`, by: ctx.senderNum });
      await saveDb();
      const maxW = groupData.maxWarns || 3;
      if (user.warns[chatJid] >= maxW && ctx.isBotAdmin) {
        await ctx.sock.groupParticipantsUpdate(chatJid, [targetJid], 'remove').catch(() => {});
        user.warns[chatJid] = 0;
        await saveDb();
        return reply(withChannelFooter(`⚠️ وصل @${targetNum} إلى الحد الأقصى للتحذيرات (${maxW}/${maxW}) وتم إخراجه بهدوء للحفاظ على نظام المجموعة.`), '🛡️', [targetJid]);
      }
      return reply(withChannelFooter(`⚠️ تم تسجيل تحذير محترم للعضو @${targetNum} (${user.warns[chatJid]}/${maxW})\n📝 *السبب:* ${reason}`), '⚠️', [targetJid]);
    }
    case 'التحذيرات': {
      const user = getUser(db, targetJid, targetNum);
      const count = user.warns[chatJid] || 0;
      return reply(withChannelFooter(`📋 *سجل التحذيرات — @${targetNum}:* ${count} / ${groupData.maxWarns || 3}`), '📋', [targetJid]);
    }
    case 'حذف_تحذير': {
      if (!isAdmin && !isOwner) return reply(withChannelFooter('🛡️ للمشرفين فقط.'), '⚠️');
      const user = getUser(db, targetJid, targetNum);
      user.warns[chatJid] = Math.max(0, (user.warns[chatJid] || 0) - 1);
      await saveDb();
      return reply(withChannelFooter(`✅ تم خصم تحذير من @${targetNum}. المتبقي: ${user.warns[chatJid]}`), '✅', [targetJid]);
    }
    case 'حظر_اوامر': {
      if (!isAdmin && !isOwner) return reply(withChannelFooter('🛡️ للمشرفين فقط.'), '⚠️');
      const user = getUser(db, targetJid, targetNum);
      user.banned = true;
      await saveDb();
      return reply(withChannelFooter(`🚫 تم منع @${targetNum} من استخدام أوامر البوت.`), '🚫', [targetJid]);
    }
    case 'فك_حظر_اوامر': {
      if (!isAdmin && !isOwner) return reply(withChannelFooter('🛡️ للمشرفين فقط.'), '⚠️');
      const user = getUser(db, targetJid, targetNum);
      user.banned = false;
      await saveDb();
      return reply(withChannelFooter(`✅ تم السماح للعضو @${targetNum} باستخدام البوت مجدداً.`), '✅', [targetJid]);
    }
    case 'سجل_المخالفات': {
      if (!isAdmin && !isOwner) return reply(withChannelFooter('🛡️ للمشرفين فقط.'), '⚠️');
      const logs = (groupData.auditLog || []).slice(-10).reverse();
      const text = logs.length
        ? logs.map((l, i) => `${i + 1}. ${l.action}`).join('\n')
        : '✨ السجل نظيف — لا توجد مخالفات مسجلة.';
      return reply(withChannelFooter(`📑 *سجل المخالفات الأمني:*\n──── 🐉⚡ ────\n${text}`), '📑');
    }
    case 'اعدادات_الحماية': {
      const f = (v) => (v ? 'نشط ✅' : 'متوقف ⚠️');
      return reply(withChannelFooter([
        `🛡️ *حالة أنظمة الحماية — ${groupMeta?.subject || 'المجموعة'}*`,
        `──── 🐉⚡ ────`,
        `✦ مضاد الروابط: ${f(groupData.antiLink)}`,
        `✦ مضاد القنوات: ${f(groupData.antiChannel)}`,
        `✦ مضاد السبام: ${f(groupData.antiSpam)}`,
        `✦ مضاد التكرار: ${f(groupData.antiRepeat)}`,
        `✦ مضاد الإعلانات: ${f(groupData.antiAds)}`,
        `✦ مضاد الإزعاج: ${f(groupData.antiFlood)}`,
        `✦ مضاد التخريب: ${f(groupData.antiRaid)}`,
        `✦ مضاد المكالمات: ${f(db.settings.antiCall)}`,
      ].join('\n')), '🛡️');
    }
  }
  return false;
}

import { getUser, saveDb } from '../lib/database.mjs';
import { withChannelFooter } from '../lib/menus.mjs';

const WORDS_POOL = [
  { word: 'تنين', hint: 'مخلوق أسطوري يظهر في شعار يحيى ديستروفا 🐉' },
  { word: 'برق', hint: 'ضوء كهربائي سريع يظهر في العواصف ⚡' },
  { word: 'خوارزمية', hint: 'مجموعة خطوات منطقية لحل مسألة برمجية 💻' },
  { word: 'مجرة', hint: 'تجمع هائل من النجوم والكواكب في الفضاء 🌌' },
  { word: 'مئذنة', hint: 'برج المسجد الذي يُرفع منه الأذان 🕌' },
];

const IQ_QUESTIONS = [
  { q: 'ما العدد التالي في المتتالية: 2، 6، 12، 20، 30، ...؟', a: '42' },
  { q: 'إذا كان 5 عمال ينهون عملاً في 5 أيام، فكم يوماً يحتاج 5 عمال لإنهاء 10 أضعاف العمل؟', a: '50' },
  { q: 'ما هو الشيء الذي كلما زاد نقص؟', a: 'العمر' },
];

const RIDDLES = [
  { q: 'يمشي بلا أرجل ويبكي بلا عيون، فما هو؟', a: 'السحاب' },
  { q: 'له أسنان كثيرة ولا يعض أبداً، فما هو؟', a: 'المشط' },
  { q: 'كلما أخذت منه كَبُر أكثر، فما هو؟', a: 'الحفرة' },
];

const TRUE_FALSE = [
  { q: 'الضوء أسرع من الصوت في الفراغ.', a: 'صح' },
  { q: 'عدد كواكب المجموعة الشمسية 9 كواكب حالياً.', a: 'خطأ' },
  { q: 'اللغة العربية تحتوي على 28 حرفاً.', a: 'صح' },
];

const TRIVIA = [
  { q: 'ما هي أكبر قارة في العالم من حيث المساحة؟', a: 'آسيا' },
  { q: 'ما هي عاصمة المملكة العربية السعودية؟', a: 'الرياض' },
  { q: 'ما هو أسرع حيوان بري في العالم؟', a: 'الفهد' },
];

function renderXoBoard(board) {
  const sym = (v, idx) => (v === 'X' ? '❌' : v === 'O' ? '⭕' : `${idx + 1}️⃣`);
  return [
    `${sym(board[0], 0)} ${sym(board[1], 1)} ${sym(board[2], 2)}`,
    `${sym(board[3], 3)} ${sym(board[4], 4)} ${sym(board[5], 5)}`,
    `${sym(board[6], 6)} ${sym(board[7], 7)} ${sym(board[8], 8)}`,
  ].join('\n');
}

function checkXoWinner(b) {
  const lines = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6],
  ];
  for (const [a, c, d] of lines) {
    if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
  }
  return b.every(Boolean) ? 'DRAW' : null;
}

export async function handleGamesCommand(ctx) {
  const { chatJid, senderJid, pushName, cmd, args, query, reply, db, prefix } = ctx;
  const user = getUser(db, senderJid, pushName);
  db.games = db.games || {};
  const chatGames = (db.games[chatJid] = db.games[chatJid] || {});

  const rewardWin = async (coins, xp) => {
    user.wallet = (user.wallet || 0) + coins;
    user.xp = (user.xp || 0) + xp;
    user.gameWins = (user.gameWins || 0) + 1;
    await saveDb();
  };

  switch (cmd) {
    case 'تخمين_رقم': {
      if (!chatGames.guessNum || args[0] === 'بدء') {
        chatGames.guessNum = { target: Math.floor(Math.random() * 100) + 1, tries: 0 };
        await saveDb();
        return reply(withChannelFooter(`🔢 *بدأت لعبة تخمين الرقم!*\nاختر رقماً من *1 إلى 100* واكتب: *${prefix}تخمين_رقم 50*`), '🔢');
      }
      const n = Number(args[0]);
      if (!Number.isInteger(n) || n < 1 || n > 100) {
        return reply(withChannelFooter(`⚠️ أدخل رقماً صحيحاً بين 1 و 100 (أو ${prefix}تخمين_رقم بدء).`), '⚠️');
      }
      chatGames.guessNum.tries += 1;
      const target = chatGames.guessNum.target;
      if (n === target) {
        const tries = chatGames.guessNum.tries;
        delete chatGames.guessNum;
        await rewardWin(250, 40);
        return reply(withChannelFooter(`🎉 أحسنت يا *${pushName}*! الرقم الصحيح هو *${target}* (بعد ${tries} محاولات)!\n💰 المكافأة: +250 عملة | +40 XP`), '🏆');
      }
      await saveDb();
      return reply(withChannelFooter(n < target ? `📈 الرقم أكبر من *${n}* — حاول مجدداً!` : `📉 الرقم أصغر من *${n}* — حاول مجدداً!`), '🎯');
    }
    case 'تخمين_كلمة': {
      if (!chatGames.guessWord || args[0] === 'بدء') {
        const picked = WORDS_POOL[Math.floor(Math.random() * WORDS_POOL.length)];
        chatGames.guessWord = { ...picked, tries: 0 };
        await saveDb();
        return reply(withChannelFooter(`🔤 *لعبة تخمين الكلمة!*\n💡 *التلميح:* ${picked.hint}\n📏 عدد الحروف: *${picked.word.length}*\nاكتب: *${prefix}تخمين_كلمة الكلمة*`), '🔤');
      }
      if (!query) return reply(withChannelFooter(`💡 التلميح الحالي: ${chatGames.guessWord.hint}`), '🔤');
      chatGames.guessWord.tries += 1;
      if (query.trim() === chatGames.guessWord.word) {
        const w = chatGames.guessWord.word;
        delete chatGames.guessWord;
        await rewardWin(200, 35);
        return reply(withChannelFooter(`🎉 إجابة صحيحة يا *${pushName}*! الكلمة هي *${w}*!\n💰 المكافأة: +200 عملة | +35 XP`), '🏆');
      }
      await saveDb();
      return reply(withChannelFooter(`❌ حاول مجدداً! التلميح: ${chatGames.guessWord.hint}`), '🔤');
    }
    case 'سؤال_ذكاء':
    case 'لغز':
    case 'سؤال_عام':
    case 'مسابقة': {
      const pool = cmd === 'سؤال_ذكاء' ? IQ_QUESTIONS : cmd === 'لغز' ? RIDDLES : TRIVIA;
      const stateKey = `quiz_${cmd}`;
      if (!chatGames[stateKey] || !query || args[0] === 'بدء') {
        const item = pool[Math.floor(Math.random() * pool.length)];
        chatGames[stateKey] = item;
        await saveDb();
        return reply(withChannelFooter(`🧠 *${item.q}*\n✍️ للإجابة اكتب: *${prefix}${cmd} إجابتك*`), '🧠');
      }
      const expected = chatGames[stateKey].a;
      if (query.trim().toLowerCase().includes(expected.toLowerCase())) {
        delete chatGames[stateKey];
        await rewardWin(180, 30);
        return reply(withChannelFooter(`🏆 إجابة صحيحة يا *${pushName}*! (*${expected}*)\n💰 +180 عملة | +30 XP`), '🎉');
      }
      return reply(withChannelFooter(`❌ إجابة غير دقيقة، حاول مجدداً أو اكتب *${prefix}${cmd} بدء* لسؤال جديد.`), '💡');
    }
    case 'صح_ام_خطأ': {
      if (!chatGames.tf || !query || args[0] === 'بدء') {
        const item = TRUE_FALSE[Math.floor(Math.random() * TRUE_FALSE.length)];
        chatGames.tf = item;
        await saveDb();
        return reply(withChannelFooter(`⚖️ *صح أم خطأ:*\n"${item.q}"\n✍️ اكتب: *${prefix}صح_ام_خطأ صح* أو *خطأ*`), '⚖️');
      }
      const ans = args[0]?.trim();
      const expected = chatGames.tf.a;
      delete chatGames.tf;
      if (ans === expected) {
        await rewardWin(120, 20);
        return reply(withChannelFooter(`✅ أحسنت يا *${pushName}*! الإجابة صحيحة (*${expected}*). (+120 عملة)`), '🏆');
      }
      await saveDb();
      return reply(withChannelFooter(`❌ الإجابة الصحيحة كانت: *${expected}*`), '⚖️');
    }
    case 'حجر': {
      const map = { 'حجر': 'rock', 'ورقة': 'paper', 'مقص': 'scissors', rock: 'rock', paper: 'paper', scissors: 'scissors' };
      const labels = { rock: '🪨 حجر', paper: '📄 ورقة', scissors: '✂️ مقص' };
      const p = map[args[0]?.toLowerCase()];
      if (!p) return reply(withChannelFooter(`✊ اختر: *${prefix}حجر حجر* أو *ورقة* أو *مقص*`), '✊');
      const opts = ['rock', 'paper', 'scissors'];
      const bot = opts[Math.floor(Math.random() * opts.length)];
      let res = '🤝 تعادل!';
      if ((p === 'rock' && bot === 'scissors') || (p === 'paper' && bot === 'rock') || (p === 'scissors' && bot === 'paper')) {
        res = '🏆 فزت! (+100 عملة)';
        await rewardWin(100, 15);
      } else if (p !== bot) {
        res = '🤖 فاز البوت هذه الجولة!';
      }
      return reply(withChannelFooter(`✊ *حجر ورقة مقص:*\nأنت: ${labels[p]} | البوت: ${labels[bot]}\n${res}`), '✊');
    }
    case 'اكس_او': {
      if (!chatGames.xo || args[0] === 'بدء') {
        chatGames.xo = { board: Array(9).fill(null) };
        await saveDb();
        return reply(withChannelFooter(`❌⭕ *بدأت مباراة XO ضد البوت!*\n${renderXoBoard(chatGames.xo.board)}\n✍️ اختر رقم خانة (1-9): *${prefix}اكس_او 5*`), '🎮');
      }
      const pos = Number(args[0]) - 1;
      const b = chatGames.xo.board;
      if (!Number.isInteger(pos) || pos < 0 || pos > 8 || b[pos]) {
        return reply(withChannelFooter(`⚠️ اختر خانة فارغة من 1 إلى 9:\n${renderXoBoard(b)}`), '⚠️');
      }
      b[pos] = 'X';
      let win = checkXoWinner(b);
      if (!win) {
        const empty = b.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
        if (empty.length) {
          const pick = empty[Math.floor(Math.random() * empty.length)];
          b[pick] = 'O';
        }
        win = checkXoWinner(b);
      }
      if (win) {
        delete chatGames.xo;
        if (win === 'X') await rewardWin(300, 50);
        else await saveDb();
        const msgEnd = win === 'X' ? '🏆 مبروك الفوز! (+300 عملة)' : win === 'O' ? '🤖 فاز البوت!' : '🤝 انتهت المباراة بالتعادل!';
        return reply(withChannelFooter(`${renderXoBoard(b)}\n──── 🐉⚡ ────\n${msgEnd}`), '🎮');
      }
      await saveDb();
      return reply(withChannelFooter(`${renderXoBoard(b)}\nدورك! اختر الرقم التالي (*${prefix}اكس_او رقم*)`), '🎮');
    }
    case 'شطرنج': {
      if (!chatGames.chess || args[0] === 'بدء') {
        chatGames.chess = { moves: [] };
        await saveDb();
        return reply(withChannelFooter(`♟️ *تم فتح طاولة الشطرنج!*\nأبيض: ${pushName} | أسود: 𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀\n✍️ أرسل حركتك بصيغة: *${prefix}شطرنج e2e4*`), '♟️');
      }
      const move = args[0] || '';
      if (!/^[a-h][1-8][a-h][1-8]$/i.test(move)) {
        return reply(withChannelFooter(`♟️ أدخل حركة شطرنج صحيحة مثل e2e4 (سجل الحركات: ${chatGames.chess.moves.join(', ') || 'بداية اللعب'})`), '♟️');
      }
      chatGames.chess.moves.push(move.toLowerCase());
      const botReplies = ['e7e5', 'c7c5', 'd7d5', 'g8f6', 'b8c6'];
      const botMove = botReplies[chatGames.chess.moves.length % botReplies.length];
      chatGames.chess.moves.push(botMove);
      await saveDb();
      return reply(withChannelFooter(`♟️ حركتك: *${move}* | رد البوت: *${botMove}*\n📜 السجل: ${chatGames.chess.moves.slice(-8).join(' → ')}`), '♟️');
    }
    case 'دومينو': {
      if (!chatGames.domino || args[0] === 'بدء') {
        const hand = ['[6|6]', '[5|3]', '[4|2]', '[1|1]'];
        chatGames.domino = { round: 1, score: 0, hand };
        await saveDb();
        return reply(withChannelFooter(`🁣 *بدأت جولة الدومينو!*\nأحجارك: ${hand.join(' ')}\nاكتب *${prefix}دومينو سحب* للعب الجولة.`), '🁣');
      }
      const pts = Math.floor(Math.random() * 12) + 2;
      delete chatGames.domino;
      await rewardWin(110, 15);
      return reply(withChannelFooter(`🁣 لعبت حجر الحسم وسجلت *${pts}* نقطة! (+110 عملة)`), '🏆');
    }
    case 'عجلة_الحظ':
    case 'حظ': {
      const prizes = [50, 100, 150, 250, 500, 75];
      const prize = prizes[Math.floor(Math.random() * prizes.length)];
      const pct = Math.floor(Math.random() * 61) + 40;
      await rewardWin(prize, 20);
      return reply(withChannelFooter(`🎡 *نتيجة الحظ اليوم يا ${pushName}:* ${pct}%\n💰 الجائزة المضافة لرصيدك: *+${prize} عملة* و *+20 XP*!`), '🎡');
    }
    case 'تحدي': {
      const challenges = [
        'اكتب الآن رسالة شكر أو تشجيع لأحد أصدقائك في المجموعة 🌟',
        'شارك أفضل معلومة مفيدة تعلمتها هذا الأسبوع 💡',
        'أرسل دعاءً جميلاً يدخل السرور على أعضاء المجموعة 🤲',
      ];
      const picked = challenges[Math.floor(Math.random() * challenges.length)];
      await rewardWin(80, 15);
      return reply(withChannelFooter(`🔥 *تحدي اليوم:*\n${picked}\n🎁 مكافأة المشاركة: +80 عملة`), '🔥');
    }
    case 'حقيقة': {
      const facts = [
        'هل تعلم أن العسل الطبيعي لا يفسد أبداً عبر الزمن؟ 🍯',
        'هل تعلم أن قلب الحوت الأزرق يزن حوالي 180 كيلوجراماً؟ 🐋',
        'هل تعلم أن كوكب الزهرة يدور حول نفسه عكس معظم الكواكب؟ 🪐',
      ];
      return reply(withChannelFooter(`💡 *حقيقة علمية:*\n${facts[Math.floor(Math.random() * facts.length)]}`), '💡');
    }
    case 'نرد': {
      const roll = Math.floor(Math.random() * 6) + 1;
      return reply(withChannelFooter(`🎲 *رمية النرد:* حصلت على الرقم *${roll}*!`), '🎲');
    }
  }
  return false;
}

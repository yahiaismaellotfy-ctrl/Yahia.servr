import { getGroup, getUser, saveDb } from '../lib/database.mjs';
import { withChannelFooter } from '../lib/menus.mjs';

const AZKAR_SABAH = [
  'أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
  'اللهم بك أصبحنا، وبك أمسينا، وبك نحيا، وبك نموت، وإليك النشور.',
  'رضيت بالله رباً، وبالإسلام ديناً، وبمحمد ﷺ نبياً ورسولاً (3 مرات).',
];

const AZKAR_MASAA = [
  'أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
  'اللهم بك أمسينا، وبك أصبحنا، وبك نحيا، وبك نموت، وإليك المصير.',
  'أعوذ بكلمات الله التامات من شر ما خلق (3 مرات).',
];

const AZKAR_SLEEP = [
  'باسمك ربي وضعت جنبي، وبك أرفعه، فإن أمسكت نفسي فارحمها، وإن أرسلتها فاحفظها بما تحفظ به عبادك الصالحين.',
  'اللهم قني عذابك يوم تبعث عبادك (3 مرات).',
];

const HADITHS = [
  { text: 'قال رسول الله ﷺ: «إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى».', source: 'متفق عليه — رواه البخاري ومسلم' },
  { text: 'قال رسول الله ﷺ: «كلمتان خفيفتان على اللسان، ثقيلتان في الميزان، حبيبتان إلى الرحمن: سبحان الله وبحمده، سبحان الله العظيم».', source: 'متفق عليه — رواه البخاري ومسلم' },
  { text: 'قال رسول الله ﷺ: «المسلم من سلم المسلمون من لسانه ويده».', source: 'متفق عليه — رواه البخاري ومسلم' },
];

const ASMA_ALLAH = 'الله، الرحمن، الرحيم، الملك، القدوس، السلام، المؤمن، المهيمن، العزيز، الجبار، المتكبر، الخالق، البارئ، المصور، الغفار، القهار، الوهاب، الرزاق، الفتاح، العليم، القابض، الباسط، الخافض، الرافع، المعز، المذل، السميع، البصير، الحكم، العدل، اللطيف، الخبير، الحليم، العظيم، الغفور، الشكور، العلي، الكبير، الحفيظ، المقيت، الحسيب، الجليل، الكريم، الرقيب، المجيب، الواسع، الحكيم، الودود، المجيد، الباعث، الشهيد، الحق، الوكيل، القوي، المتين، الولي، الحميد، المحصي، المبدئ، المعيد، المحيي، المميت، الحي، القيوم، الواجد، الماجد، الواحد، الصمد، القادر، المقتدر، المقدم، المؤخر، الأول، الآخر، الظاهر، الباطن، الوالي، المتعالي، البر، التواب، المنتقم، العفو، الرؤوف، مالك الملك، ذو الجلال والإكرام، المقسط، الجامع، الغني، المغني، المانع، الضار، النافع، النور، الهادي، البديع، الباقي، الوارث، الرشيد، الصبور.';

export async function handleIslamicCommand(ctx) {
  const { chatJid, isGroup, isAdmin, isOwner, senderJid, pushName, cmd, args, query, reply, db } = ctx;
  const user = getUser(db, senderJid, pushName);

  switch (cmd) {
    case 'قران': {
      const ref = (query || '1').trim();
      const url = ref.includes(':')
        ? `https://api.alquran.cloud/v1/ayah/${encodeURIComponent(ref)}/quran-uthmani`
        : `https://api.alquran.cloud/v1/surah/${encodeURIComponent(ref)}/quran-uthmani`;
      const res = await fetch(url, { signal: AbortSignal.timeout(8000) }).then((r) => r.json()).catch(() => null);
      if (res?.code !== 200) return reply(withChannelFooter('⚠️ أدخل رقم سورة (1-114) أو آية بصيغة 2:255.'), '⚠️');
      if (res.data?.ayahs) {
        const ayahs = res.data.ayahs.slice(0, 10).map((a) => `(${a.numberInSurah}) ${a.text}`).join(' ');
        return reply(withChannelFooter(`📖 *سورة ${res.data.name}* (${res.data.numberOfAyahs} آية)\n──── 🐉⚡ ────\n${ayahs}`), '📖');
      }
      return reply(withChannelFooter(`📖 *سورة ${res.data.surah?.name} — آية ${res.data.numberInSurah}:*\n${res.data.text}`), '📖');
    }
    case 'تلاوة': {
      const num = String(Math.max(1, Math.min(114, Number(args[0]) || 1))).padStart(3, '0');
      const audioUrl = `https://server8.mp3quran.net/afs/${num}.mp3`;
      await ctx.sock.sendMessage(chatJid, { audio: { url: audioUrl }, mimetype: 'audio/mpeg' }).catch(async () => {
        await reply(withChannelFooter(`🎧 رابط التلاوة المباشر:\n${audioUrl}`), '🎧');
      });
      return true;
    }
    case 'تفسير': {
      const ref = (query || '112:1').trim();
      const res = await fetch(`https://api.alquran.cloud/v1/ayah/${encodeURIComponent(ref)}/ar.muyassar`, { signal: AbortSignal.timeout(8000) }).then((r) => r.json()).catch(() => null);
      if (res?.code !== 200 || !res.data?.text) return reply(withChannelFooter('⚠️ أدخل رقم السورة والآية مثل: 112:1'), '⚠️');
      return reply(withChannelFooter(`📚 *التفسير الميسر (${ref}):*\n──── 🐉⚡ ────\n${res.data.text}`), '📚');
    }
    case 'اذكار_الصباح': {
      return reply(withChannelFooter(`☀️ *أذكار الصباح:*\n──── 🐉⚡ ────\n${AZKAR_SABAH.map((z, i) => `${i + 1}. ${z}`).join('\n\n')}`), '☀️');
    }
    case 'اذكار_المساء': {
      return reply(withChannelFooter(`🌙 *أذكار المساء:*\n──── 🐉⚡ ────\n${AZKAR_MASAA.map((z, i) => `${i + 1}. ${z}`).join('\n\n')}`), '🌙');
    }
    case 'اذكار_النوم': {
      return reply(withChannelFooter(`🛌 *أذكار النوم:*\n──── 🐉⚡ ────\n${AZKAR_SLEEP.map((z, i) => `${i + 1}. ${z}`).join('\n\n')}`), '🌙');
    }
    case 'استغفار': {
      user.tasbih = (user.tasbih || 0) + 1;
      await saveDb();
      return reply(withChannelFooter(`🤲 *أستغفر الله العظيم وأتوب إليه*\n📿 مجموع تسبيحك واستغفارك المسجل: *${user.tasbih}*`), '📿');
    }
    case 'دعاء': {
      return reply(withChannelFooter('🤲 «ربنا آتنا في الدنيا حسنة وفي الآخرة حسنة وقنا عذاب النار، اللهم اشرح صدورنا ويسّر أمورنا».'), '🤲');
    }
    case 'مواقيت_الصلاة': {
      const city = (query || 'Cairo').trim();
      const res = await fetch(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=&method=5`, { signal: AbortSignal.timeout(8000) }).then((r) => r.json()).catch(() => null);
      const t = res?.data?.timings;
      if (!t) return reply(withChannelFooter('⚠️ تعذر جلب المواقيت حالياً. تأكد من اسم المدينة.'), '⚠️');
      return reply(withChannelFooter([
        `🕌 *مواقيت الصلاة في ${city}:*`,
        `──── 🐉⚡ ────`,
        `✦ الفجر: ${t.Fajr}`,
        `✦ الشروق: ${t.Sunrise}`,
        `✦ الظهر: ${t.Dhuhr}`,
        `✦ العصر: ${t.Asr}`,
        `✦ المغرب: ${t.Maghrib}`,
        `✦ العشاء: ${t.Isha}`,
      ].join('\n')), '🕌');
    }
    case 'قبلة': {
      const city = (query || 'Cairo').trim();
      const geo = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`, { signal: AbortSignal.timeout(7000) }).then((r) => r.json()).catch(() => null);
      const loc = geo?.results?.[0];
      if (!loc) return reply(withChannelFooter('⚠️ لم يتم العثور على إحداثيات المدينة.'), '⚠️');
      const qRes = await fetch(`https://api.aladhan.com/v1/qibla/${loc.latitude}/${loc.longitude}`, { signal: AbortSignal.timeout(7000) }).then((r) => r.json()).catch(() => null);
      const deg = qRes?.data?.direction?.toFixed(2);
      return reply(withChannelFooter(`🧭 *اتجاه القبلة من ${loc.name}:* *${deg}°* من الشمال الجغرافي.`), '🧭');
    }
    case 'حديث': {
      const h = HADITHS[Math.floor(Math.random() * HADITHS.length)];
      return reply(withChannelFooter(`📜 *حديث نبوي شريف:*\n──── 🐉⚡ ────\n${h.text}\n\n📚 *المصدر:* ${h.source}`), '📜');
    }
    case 'اسماء_الله': {
      return reply(withChannelFooter(`✨ *أسماء الله الحسنى الـ 99:*\n──── 🐉⚡ ────\n${ASMA_ALLAH}`), '✨');
    }
    case 'صلاة_على_النبي': {
      return reply(withChannelFooter('ﷺ *اللهم صلِّ وسلم وبارك على نبينا محمد وعلى آله وصحبه أجمعين.*'), '🤍');
    }
    case 'تذكير_يومي': {
      if (!isGroup) return reply(withChannelFooter('⚠️ يعمل داخل المجموعات فقط.'), '⚠️');
      if (!isAdmin && !isOwner) return reply(withChannelFooter('🛡️ للمشرفين فقط.'), '⚠️');
      const g = getGroup(db, chatJid);
      const v = String(args[0] || '').toLowerCase();
      if (['تشغيل', 'on', '1'].includes(v)) g.dailyReminder = true;
      else if (['ايقاف', 'إيقاف', 'off', '0'].includes(v)) g.dailyReminder = false;
      await saveDb();
      return reply(withChannelFooter(`🕌 *رسائل التذكير اليومية:* ${g.dailyReminder ? 'مفعّلة ✅' : 'متوقفة ⚠️'}`), '🕌');
    }
  }
  return false;
}

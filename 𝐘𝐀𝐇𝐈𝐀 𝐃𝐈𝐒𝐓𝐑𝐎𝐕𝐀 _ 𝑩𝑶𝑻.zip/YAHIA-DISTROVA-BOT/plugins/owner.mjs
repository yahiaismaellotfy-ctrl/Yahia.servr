import os from 'os';
import fs from 'fs-extra';
import { getBackupSnapshot, restoreBackupSnapshot, saveDb } from '../lib/database.mjs';
import { formatUptime, withChannelFooter } from '../lib/menus.mjs';

export async function handleOwnerCommand(ctx) {
  const { sock, isOwner, cmd, query, reply, db, config, commandsCount, categoriesCount } = ctx;

  if (cmd === 'المطور') {
    return reply(withChannelFooter([
      `👑 *بطاقة المطور الرسمية* ⚡`,
      `──── 🐉⚡ ────`,
      `✦ *البوابة:* ${config.portalName}`,
      `✦ *اسم البوت:* ${config.botName} 🤖`,
      `✦ *المطور:* ${config.developerBadge || config.developerName} 👨‍💻`,
      `📡 *القناة الرسمية:* ${config.officialChannelUrl}`,
      `💬 *مجموعة الدعم:* ${config.installGroupUrl}`,
    ].join('\n')), '👑');
  }

  if (!isOwner) {
    return reply(withChannelFooter('👑 هذا الأمر مخصص لمالك ومطور البوت فقط.'), '⚠️');
  }

  switch (cmd) {
    case 'اعدادات': {
      return reply(withChannelFooter([
        `⚙️ *إعدادات البوت الحالية* ⚡`,
        `──── 🐉⚡ ────`,
        `🤖 *الاسم:* ${config.botName}`,
        `🔑 *البادئة:* ${db.settings.prefix}`,
        `🛡️ *مضاد المكالمات:* ${db.settings.antiCall ? 'نشط ✅' : 'متوقف ⚠️'}`,
        `📡 *الوضع:* ${db.settings.publicMode ? 'عام للجميع' : 'خاص بالمالك'}`,
        `🔧 *الصيانة:* ${db.settings.maintenance ? 'مفعّلة' : 'غير مفعّلة'}`,
      ].join('\n')), '⚙️');
    }
    case 'اذاعة': {
      if (!query) return reply(withChannelFooter('📣 اكتب نص الإعلان العام بعد الأمر.'), 'ℹ️');
      const groups = await sock.groupFetchAllParticipating().catch(() => ({}));
      const groupJids = Object.keys(groups);
      let sent = 0;
      for (const gjid of groupJids) {
        try {
          await sock.sendMessage(gjid, { text: withChannelFooter(`📣 *إعلان من المطور:*\n──── 🐉⚡ ────\n${query}`) });
          sent += 1;
        } catch {}
      }
      return reply(withChannelFooter(`✅ تم إرسال الإعلان بنجاح إلى *${sent}* مجموعة.`), '📣');
    }
    case 'اعادة_تشغيل': {
      db.stats.lastRestartAt = Date.now();
      await saveDb();
      await reply(withChannelFooter('🔄 جاري حفظ قاعدة البيانات وإعادة تشغيل البوت...'), '🔄');
      setTimeout(() => process.exit(0), 1200);
      return true;
    }
    case 'فحص_النظام': {
      const mem = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
      const load = os.loadavg()[0]?.toFixed(2) || '0.00';
      return reply(withChannelFooter([
        `⚙️ *تقرير فحص النظام الحقيقي* ⚡`,
        `──── 🐉⚡ ────`,
        `📡 *اتصال واتساب:* متصل ✅`,
        `💾 *قاعدة البيانات:* متصلة ومحفوظة ✅`,
        `⚡ *الأوامر:* ${commandsCount} (${categoriesCount} قسم)`,
        `✅ *ناجحة:* ${db.stats.totalSuccess} | ❌ *أخطاء:* ${db.stats.totalErrors}`,
        `🔋 *الرام:* ${mem} MB | 🖥️ *المعالج:* ${load}`,
        `⏱️ *التشغيل:* ${formatUptime(Date.now() - db.stats.startedAt)}`,
      ].join('\n')), '⚙️');
    }
    case 'فحص_القاعدة': {
      const exists = await fs.pathExists(config.dbPath);
      const stat = exists ? await fs.stat(config.dbPath) : null;
      return reply(withChannelFooter([
        `💾 *فحص قاعدة البيانات* ⚡`,
        `──── 🐉⚡ ────`,
        `📁 *الحالة:* ${exists ? 'موجودة ومتصلة ✅' : 'غير موجودة ❌'}`,
        `📦 *الحجم:* ${stat ? (stat.size / 1024).toFixed(2) + ' KB' : '0 KB'}`,
        `👥 *المستخدمون:* ${Object.keys(db.users || {}).length}`,
        `🌐 *المجموعات:* ${Object.keys(db.groups || {}).length}`,
      ].join('\n')), '💾');
    }
    case 'عدد_المستخدمين': {
      return reply(withChannelFooter(`👥 *إجمالي المستخدمين المسجلين فعلياً:* *${Object.keys(db.users || {}).length}* مستخدم.`), '👥');
    }
    case 'عدد_المجموعات': {
      const groups = await sock.groupFetchAllParticipating().catch(() => ({}));
      const liveCount = Object.keys(groups).length;
      return reply(withChannelFooter(`🌐 *المجموعات النشطة:* *${Math.max(liveCount, Object.keys(db.groups || {}).length)}* مجموعة.`), '🌐');
    }
    case 'تغيير_اسم_البوت': {
      if (!query) return reply(withChannelFooter('✏️ اكتب الاسم الجديد للبوت.'), 'ℹ️');
      config.botName = query;
      db.settings.botName = query;
      await saveDb();
      return reply(withChannelFooter(`✅ تم تغيير اسم البوت إلى: *${query}*`), '✅');
    }
    case 'تغيير_المالك': {
      const clean = query.replace(/\D/g, '');
      if (clean.length < 10) return reply(withChannelFooter('📱 أدخل رقم المالك الدولي الصحيح (مثال: 201275063625).'), 'ℹ️');
      if (!config.owners.includes(clean)) config.owners.push(clean);
      db.settings.ownerNumber = clean;
      await saveDb();
      return reply(withChannelFooter(`✅ تم اعتماد رقم المالك: *${clean}*`), '👑');
    }
    case 'تحديث_القناة': {
      if (!query.includes('whatsapp.com/channel')) return reply(withChannelFooter('⚠️ أدخل رابط قناة واتساب صحيح.'), '⚠️');
      config.officialChannelUrl = query.trim();
      db.settings.officialChannelUrl = query.trim();
      await saveDb();
      return reply(withChannelFooter('✅ تم تحديث رابط القناة الرسمية في الإعدادات.'), '📡');
    }
    case 'تحديث_الدعم': {
      if (!query.includes('chat.whatsapp.com')) return reply(withChannelFooter('⚠️ أدخل رابط مجموعة دعم واتساب صحيح.'), '⚠️');
      config.installGroupUrl = query.trim();
      db.settings.installGroupUrl = query.trim();
      await saveDb();
      return reply(withChannelFooter('✅ تم تحديث رابط مجموعة الدعم في الإعدادات.'), '💬');
    }
    case 'سجل_الاخطاء': {
      const errors = (db.stats.errorLog || []).slice(-8).reverse();
      const text = errors.length
        ? errors.map((e, i) => `${i + 1}. [${e.cmd}] ${e.message}`).join('\n')
        : '✅ لا توجد أخطاء مسجلة حتى الآن.';
      return reply(withChannelFooter(`🐞 *سجل أخطاء النظام:*\n──── 🐉⚡ ────\n${text}`), '🐞');
    }
    case 'نسخة_احتياطية': {
      const snap = await getBackupSnapshot();
      await sock.sendMessage(ctx.chatJid, {
        document: Buffer.from(JSON.stringify(snap, null, 2), 'utf8'),
        mimetype: 'application/json',
        fileName: `yahia-distrova-backup-${Date.now()}.json`,
        caption: withChannelFooter('💾 نسخة احتياطية كاملة لقاعدة بيانات البوت.'),
      });
      return true;
    }
    case 'استعادة_نسخة': {
      const restored = await restoreBackupSnapshot();
      if (!restored) return reply(withChannelFooter('⚠️ لا توجد نسخة احتياطية محفوظة مسبقاً لاستعادتها.'), '⚠️');
      return reply(withChannelFooter('✅ تم استعادة قاعدة البيانات من آخر نسخة احتياطية بنجاح.'), '💾');
    }
  }
  return false;
}

import { getGroup, getUser, saveDb } from '../lib/database.mjs';
import { withChannelFooter } from '../lib/menus.mjs';

function parseToggle(arg) {
  const v = String(arg || '').trim().toLowerCase();
  if (['تشغيل', 'تفعيل', 'on', '1'].includes(v)) return true;
  if (['ايقاف', 'إيقاف', 'تعطيل', 'off', '0'].includes(v)) return false;
  return null;
}

export async function handleProfileCommand(ctx) {
  const { sock, msg, chatJid, isGroup, isAdmin, isOwner, senderJid, senderNum, pushName, cmd, args, query, reply, db, groupMeta } = ctx;
  const msgCtx = ctx.getMessageContextInfo(msg);
  const targetJid =
    cmd === 'صورتي' || cmd === 'حفظ_صورتي' || cmd === 'معلوماتي'
      ? senderJid
      : msgCtx?.mentionedJid?.[0] || msgCtx?.participant || senderJid;
  const targetNum = targetJid.split(':')[0].split('@')[0];
  const targetUser = getUser(db, targetJid, targetNum === senderNum ? pushName : targetNum);

  if (isGroup && ['ترحيب', 'رسالة_ترحيب', 'رسالة_توديع'].includes(cmd)) {
    if (!isAdmin && !isOwner) return reply(withChannelFooter('🛡️ إعدادات الترحيب للمشرفين فقط.'), '⚠️');
    const gData = getGroup(db, chatJid);
    if (cmd === 'ترحيب') {
      const next = parseToggle(args[0]);
      if (next !== null) {
        gData.welcome = next;
        await saveDb();
      }
      return reply(withChannelFooter(`💬 *نظام الترحيب والتوديع:* ${gData.welcome ? 'نشط ✅' : 'متوقف ⚠️'}`), '💬');
    }
    if (cmd === 'رسالة_ترحيب') {
      if (!query) return reply(withChannelFooter('✏️ اكتب نص الترحيب. يمكنك استخدام @user و @group'), 'ℹ️');
      gData.welcomeText = query;
      await saveDb();
      return reply(withChannelFooter('✅ تم تحديث رسالة الترحيب المخصصة للمجموعة.'), '✅');
    }
    if (cmd === 'رسالة_توديع') {
      if (!query) return reply(withChannelFooter('✏️ اكتب نص التوديع. يمكنك استخدام @user و @group'), 'ℹ️');
      gData.goodbyeText = query;
      await saveDb();
      return reply(withChannelFooter('✅ تم تحديث رسالة التوديع المخصصة للمجموعة.'), '✅');
    }
  }

  switch (cmd) {
    case 'بروفايل':
    case 'صورتي':
    case 'حفظ_صورتي': {
      const ppUrl = await sock.profilePictureUrl(targetJid, 'image').catch(() => '');
      if (!ppUrl) {
        return reply(withChannelFooter(`🔒 تعذر عرض صورة @${targetNum} — الصورة غير متاحة أو مخفية حسب إعدادات خصوصية المستخدم.`), '🔒', [targetJid]);
      }
      const rankRole = targetUser.title || (targetUser.level >= 10 ? 'أسطورة الديستروفا 👑' : targetUser.level >= 5 ? 'نخبة الأعضاء ⚡' : 'عضو نشط ✨');
      const caption = withChannelFooter([
        `📸 *بطاقة البروفايل* ⚡`,
        `──── 🐉⚡ ────`,
        `👤 *الحساب:* @${targetNum}`,
        `🏅 *اللقب:* ${rankRole}`,
        `⭐ *المستوى:* ${targetUser.level} (XP: ${targetUser.xp})`,
        `💰 *الرصيد:* ${(targetUser.wallet || 0) + (targetUser.bank || 0)} عملة`,
        cmd === 'حفظ_صورتي' ? `💾 *الصورة جاهزة للحفظ مباشرة بأعلى دقة متاحة.*` : '',
      ].filter(Boolean).join('\n'));
      await sock.sendMessage(chatJid, { image: { url: ppUrl }, caption, mentions: [targetJid] });
      return true;
    }
    case 'معلوماتي':
    case 'معلومات': {
      const joinedDate = new Date(targetUser.registeredAt || Date.now()).toLocaleDateString('ar-EG');
      return reply(withChannelFooter([
        `🪪 *معلومات الحساب المتاحة* ⚡`,
        `──── 🐉⚡ ────`,
        `👤 *الاسم:* ${targetUser.name || targetNum}`,
        `🏷️ *الحساب:* @${targetNum}`,
        `🏅 *اللقب:* ${targetUser.title || 'بدون لقب مخصص'}`,
        `⭐ *المستوى:* ${targetUser.level} | *النقاط:* ${targetUser.xp} XP`,
        `💬 *الرسائل المسجلة:* ${targetUser.messages || 0}`,
        `📅 *تاريخ التسجيل:* ${joinedDate}`,
      ].join('\n')), '🪪', [targetJid]);
    }
    case 'نقاطي':
    case 'مستواي': {
      const nextXp = targetUser.level * 150;
      return reply(withChannelFooter(`⭐ *المستوى والخبرة:*\n✦ المستوى الحالي: *${targetUser.level}*\n✦ نقاط النشاط: *${targetUser.xp} / ${nextXp}* XP`), '⭐');
    }
    case 'ترتيبي': {
      const sorted = Object.values(db.users || {}).sort((a, b) => (b.xp || 0) - (a.xp || 0));
      const idx = sorted.findIndex((u) => u.jid === senderJid);
      return reply(withChannelFooter(`🏆 *ترتيبك العام:* المركز *${idx >= 0 ? idx + 1 : sorted.length}* من أصل *${sorted.length}* عضو.`), '🏆');
    }
    case 'ترتيب': {
      const top = Object.values(db.users || {}).sort((a, b) => (b.xp || 0) - (a.xp || 0)).slice(0, 10);
      const lines = top.map((u, i) => `${i + 1}. *${u.name || 'عضو'}* — مستوى ${u.level} (${u.xp} XP)`).join('\n');
      return reply(withChannelFooter(`🏆 *ترتيب الأعضاء الأكثر تفاعلاً:*\n──── 🐉⚡ ────\n${lines || 'لا توجد بيانات بعد.'}`), '🏆');
    }
    case 'نشاط': {
      const gMsgs = Object.values(db.users || {}).reduce((acc, u) => acc + (u.groupMessages?.[chatJid] || 0), 0);
      return reply(withChannelFooter(`📊 *إحصائيات التفاعل:*\n✦ رسائل مسجلة في الشات: *${gMsgs}*\n✦ رسائلك: *${targetUser.groupMessages?.[chatJid] || targetUser.messages || 0}*`), '📊');
    }
    case 'إنجازاتي': {
      const badges = [];
      if (targetUser.messages >= 10) badges.push('💬 متفاعل نشط');
      if (targetUser.level >= 3) badges.push('⭐ نجم متصاعد');
      if ((targetUser.bank || 0) >= 5000) badges.push('🏦 مستثمر ذكي');
      if ((targetUser.gameWins || 0) >= 1) badges.push('🎮 بطل التحديات');
      return reply(withChannelFooter(`🎖️ *إنجازاتك:*\n──── 🐉⚡ ────\n${badges.length ? badges.join('\n') : '✨ تفاعل في الشات والألعاب لفتح أول أوسمتك!'}`), '🎖️');
    }
    case 'لقبي': {
      if (query) {
        targetUser.title = query.slice(0, 32);
        await saveDb();
        return reply(withChannelFooter(`✅ تم تعيين لقبك الجديد: *${targetUser.title}*`), '🏅');
      }
      return reply(withChannelFooter(`🏅 *لقبك الحالي:* ${targetUser.title || 'لم يتم تعيين لقب بعد.'}`), '🏅');
    }
    case 'عائلتي': {
      targetUser.family = targetUser.family || [];
      if (args[0] === 'إضافة' && msgCtx?.mentionedJid?.[0]) {
        const friend = msgCtx.mentionedJid[0];
        if (!targetUser.family.includes(friend)) targetUser.family.push(friend);
        await saveDb();
        return reply(withChannelFooter(`👨‍👩‍👧‍👦 تمت إضافة @${friend.split('@')[0]} إلى قائمتك العائلية!`), '❤️', [friend]);
      }
      const list = targetUser.family.map((f, i) => `${i + 1}. @${f.split(':')[0].split('@')[0]}`).join('\n');
      return reply(withChannelFooter(`👨‍👩‍👧‍👦 *قائمة العائلة والأصدقاء:*\n──── 🐉⚡ ────\n${list || 'القائمة فارغة — استخدم .عائلتي إضافة @منشن'}`), '❤️', targetUser.family);
    }
    case 'فتح_صورة':
    case 'عرض_صورة':
    case 'حجم_الصورة':
    case 'معلومات_صورة':
    case 'تحويل_صورة':
    case 'جودة_الصورة': {
      const rawEnvelope = msgCtx?.quotedMessage || msg.message;
      const unwrapped = ctx.unwrapMessageContent(rawEnvelope);
      if (unwrapped?.viewOnceMessage || unwrapped?.viewOnceMessageV2 || rawEnvelope?.viewOnceMessage || rawEnvelope?.viewOnceMessageV2) {
        return reply(withChannelFooter('🔒 احتراماً لخصوصية المرسل، لا يقوم البوت بتجاوز الوسائط ذات العرض لمرة واحدة.'), '🔒');
      }
      const imgMsg = unwrapped?.imageMessage;
      if (!imgMsg) {
        return reply(withChannelFooter('📸 رد على صورة عادية متاحة لتنفيذ الأمر.'), 'ℹ️');
      }
      const bytes = Number(imgMsg.fileLength || 0);
      const kb = bytes ? (bytes / 1024).toFixed(1) + ' KB' : 'غير محدد';
      const dims = imgMsg.width && imgMsg.height ? `${imgMsg.width}×${imgMsg.height}` : 'قياسي';
      if (cmd === 'حجم_الصورة' || cmd === 'معلومات_صورة') {
        return reply(withChannelFooter(`🖼️ *معلومات الصورة:*\n✦ الصيغة: ${imgMsg.mimetype || 'image/jpeg'}\n✦ الأبعاد: ${dims}\n✦ الحجم: ${kb}`), '🖼️');
      }
      const stream = await ctx.downloadContentFromMessage(imgMsg, 'image');
      const chunks = [];
      for await (const c of stream) chunks.push(c);
      const buf = Buffer.concat(chunks);
      if (cmd === 'تحويل_صورة') {
        const ext = ['png', 'webp', 'jpg'].includes(args[0]?.toLowerCase()) ? args[0].toLowerCase() : 'png';
        await sock.sendMessage(chatJid, {
          document: buf,
          mimetype: ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg',
          fileName: `distrova-image.${ext}`,
          caption: withChannelFooter(`✅ تم تجهيز الصورة بصيغة *${ext.toUpperCase()}*`),
        });
        return true;
      }
      await sock.sendMessage(chatJid, {
        image: buf,
        caption: withChannelFooter(`📸 *عرض الصورة* (${dims} | ${kb})`),
      });
      return true;
    }
  }
  return false;
}

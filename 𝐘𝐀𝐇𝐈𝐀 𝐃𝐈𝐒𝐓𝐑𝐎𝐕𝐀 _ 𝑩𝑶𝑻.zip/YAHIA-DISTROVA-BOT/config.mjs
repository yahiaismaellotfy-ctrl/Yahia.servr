import 'dotenv/config';

export const config = {
  portalName: process.env.PORTAL_NAME || "اَلــديـسـتـࢪوفـا 𓆩𝒀𓆪༼𝑿𖣂",
  botName: process.env.BOT_NAME || "𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀",
  developerName: process.env.DEVELOPER_NAME || "𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀",
  developerBadge: "𝗬𝗔𝗛𝗜𝗔 𝗗𝗜𝗦𝗧𝗥𝗢𝐕𝐀𖣂",
  ownerLocal: "01275063625",
  ownerNumber: (process.env.OWNER_NUMBER || "201275063625").replace(/\D/g, ''),
  owners: [(process.env.OWNER_NUMBER || "201275063625").replace(/\D/g, '')],
  prefix: process.env.PREFIX || ".",
  pairingNumber: (process.env.PAIRING_NUMBER || "201275063625").replace(/\D/g, ''),
  installGroupUrl: process.env.INSTALL_GROUP_URL || "https://chat.whatsapp.com/I6rvFKu3Cbj0rYMsRU1wOc?s=cl&p=a&iam=2",
  officialChannelUrl: process.env.OFFICIAL_CHANNEL_URL || "https://whatsapp.com/channel/0029VbBHjuc35fLzD0p4Fu0u",
  channelJid: process.env.CHANNEL_JID || '120363300000000000@newsletter',
  sessionDir: './session',
  dbPath: './database/db.json',
  backupPath: './database/db.backup.json',
  publicMode: true,
  features: {
    antiLink: true,
    antiDelete: true,
    antiCall: true,
    welcome: true,
    autoBio: true,
    channelAutoReact: true,
    economy: true,
  },
};

export default config;

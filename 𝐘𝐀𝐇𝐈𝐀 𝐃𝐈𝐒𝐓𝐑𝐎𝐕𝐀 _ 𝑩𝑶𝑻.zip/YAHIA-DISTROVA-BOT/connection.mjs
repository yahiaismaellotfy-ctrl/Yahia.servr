import makeWASocket, {
  Browsers,
  DisconnectReason,
  fetchLatestWaWebVersion,
  useMultiFileAuthState,
} from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import pino from 'pino';
import express from 'express';
import QRCode from 'qrcode';
import qrcodeTerminal from 'qrcode-terminal';
import fs from 'fs-extra';
import config from './config.mjs';
import { getGroup, loadDb } from './lib/database.mjs';
import { buildWelcomeCaption, setResolvedChannelInfo, withChannelFooter } from './lib/menus.mjs';
import { handleIncomingMessage } from './handler.mjs';

let latestQr = '';
let latestPairCode = '';
let connectionState = 'initializing';
let isConnecting = false;
let activeSock = null;
let bioInterval = null;
let httpStarted = false;

function startWebPanel() {
  if (httpStarted) return;
  httpStarted = true;
  const app = express();
  app.use(express.json());
  const port = Number(process.env.PORT) || 3000;

  app.get('/api/status', (_req, res) => {
    res.json({
      botName: config.botName,
      portalName: config.portalName,
      state: connectionState,
      pairingCode: latestPairCode,
      hasQr: Boolean(latestQr),
    });
  });

  app.get('/', async (_req, res) => {
    const qrImg = latestQr ? await QRCode.toDataURL(latestQr).catch(() => '') : '';
    res.send(`<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${config.botName}</title><style>body{background:#07050c;color:#f5f3ff;font-family:sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0} .box{background:#120d1d;border:1px solid #8b5cf6;border-radius:16px;padding:28px;max-width:440px;text-align:center} .code{font-size:28px;letter-spacing:4px;color:#c084fc;margin:14px 0}</style></head><body><div class="box"><h2>${config.portalName}</h2><p>${config.botName} | POWER BOT</p><p>الحالة: ${connectionState}</p>${latestPairCode ? '<div class="code">' + latestPairCode + '</div>' : ''}${qrImg ? '<img src="' + qrImg + '" width="240"/>' : ''}</div></body></html>`);
  });

  app.listen(port, '0.0.0.0', () => console.log('🌐 لوحة حالة البوت على المنفذ:', port));
}

async function resolveOfficialChannel(sock) {
  try {
    const m = config.officialChannelUrl.match(/channel\/([A-Za-z0-9_-]+)/i);
    if (!m || typeof sock.newsletterMetadata !== 'function') return;
    const meta = await sock.newsletterMetadata('invite', m[1]).catch(() => null);
    if (meta?.id) {
      setResolvedChannelInfo({
        jid: meta.id,
        name: meta.name || meta.thread_metadata?.name || config.portalName,
        subscribers: meta.subscribers,
      });
    }
  } catch {}
}

export async function startBot() {
  if (isConnecting) return;
  isConnecting = true;
  startWebPanel();

  try {
    await fs.ensureDir(config.sessionDir);
    const db = await loadDb();
    const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);
    const verRes = await fetchLatestWaWebVersion().catch(() => null);

    const sock = makeWASocket({
      auth: state,
      logger: pino({ level: 'silent' }),
      printQRInTerminal: false,
      browser: Browsers.ubuntu('Chrome'),
      ...(Array.isArray(verRes?.version) ? { version: verRes.version } : {}),
    });

    activeSock = sock;
    sock.ev.on('creds.update', saveCreds);

    const useQrOnly = process.argv.includes('--qr') || process.env.PAIR_MODE === 'qr';
    const pairTarget = config.pairingNumber;
    if (!state.creds?.registered && !useQrOnly && pairTarget.length >= 10) {
      setTimeout(async () => {
        try {
          const code = await sock.requestPairingCode(pairTarget);
          latestPairCode = String(code || '').match(/.{1,4}/g)?.join('-') || code;
          console.log('🔑 كود الربط:', latestPairCode);
        } catch (e) {
          console.error('⚠️ تعذر طلب كود الربط:', e?.message || e);
        }
      }, 3000);
    }

    sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
      if (qr) {
        latestQr = qr;
        qrcodeTerminal.generate(qr, { small: true });
      }
      if (connection === 'open') {
        connectionState = 'connected';
        latestQr = '';
        isConnecting = false;
        console.log(`✅ تم اتصال ${config.botName} بنجاح!`);
        await resolveOfficialChannel(sock);

        const ownerJid = `${config.ownerNumber}@s.whatsapp.net`;
        await sock.sendMessage(ownerJid, { text: buildWelcomeCaption() }).catch(() => {});

        if (bioInterval) clearInterval(bioInterval);
        if (db.settings.autoBio) {
          bioInterval = setInterval(() => {
            const t = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
            sock.updateProfileStatus(`${config.botName} ⚡ نشط | ${t}`).catch(() => {});
          }, 60 * 1000);
        }
      } else if (connection === 'close') {
        connectionState = 'reconnecting';
        isConnecting = false;
        const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
        if (code !== DisconnectReason.loggedOut) {
          setTimeout(startBot, 4000);
        } else {
          console.log('🚪 تم تسجيل الخروج — احذف مجلد session وأعد الربط.');
        }
      }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      if (type !== 'notify') return;
      for (const m of messages) {
        await handleIncomingMessage(sock, m);
      }
    });

    sock.ev.on('group-participants.update', async (ev) => {
      if (!['add', 'remove'].includes(ev.action)) return;
      const gData = getGroup(db, ev.id);
      if (!gData.welcome) return;
      const meta = await sock.groupMetadata(ev.id).catch(() => null);
      const groupTitle = meta?.subject || 'المجموعة';
      const count = meta?.participants?.length || 0;
      const joinDate = new Date().toLocaleDateString('ar-EG');

      for (const p of ev.participants || []) {
        const jid = typeof p === 'string' ? p : p?.id || '';
        const num = jid.split(':')[0].split('@')[0];
        const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => '');
        const template = ev.action === 'add' ? gData.welcomeText : gData.goodbyeText;
        const text = withChannelFooter([
          ev.action === 'add' ? `🐉 *ترحيب بالعضو الجديد* ⚡` : `👋 *وداع عضو*`,
          `──── 🐉⚡ ────`,
          template.replace(/@user/g, `@${num}`).replace(/@group/g, groupTitle),
          `👥 *عدد الأعضاء:* ${count} | 📅 *${joinDate}*`,
        ].join('\n'));
        if (ppUrl) {
          await sock.sendMessage(ev.id, { image: { url: ppUrl }, caption: text, mentions: [jid] }).catch(async () => {
            await sock.sendMessage(ev.id, { text, mentions: [jid] }).catch(() => {});
          });
        } else {
          await sock.sendMessage(ev.id, { text, mentions: [jid] }).catch(() => {});
        }
      }
    });

    sock.ev.on('call', async (calls) => {
      if (!db.settings.antiCall) return;
      for (const c of calls) {
        if (c.status === 'offer' && typeof sock.rejectCall === 'function') {
          await sock.rejectCall(c.id, c.from).catch(() => {});
        }
      }
    });
  } catch (err) {
    isConnecting = false;
    console.error('❌ خطأ في الاتصال:', err?.message || err);
    setTimeout(startBot, 5000);
  }
}

startBot();

import('./connection.mjs').catch((err) => {
  console.error('❌ فشل تشغيل البوت:', err);
  process.exit(1);
});

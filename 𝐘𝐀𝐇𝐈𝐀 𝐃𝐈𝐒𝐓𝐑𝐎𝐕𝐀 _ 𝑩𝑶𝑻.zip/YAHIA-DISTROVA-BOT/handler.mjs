import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import config from './config.mjs';
import { getGroup, getUser, loadDb, saveDb } from './lib/database.mjs';
import {
  buildContextInfo,
  findCommand,
  formatCategoryMenu,
  getResolvedChannelInfo,
  withChannelFooter,
} from './lib/menus.mjs';
import { getBannerBuffer } from './lib/mediaAssets.mjs';
import { COMMANDS, CATEGORIES } from './lib/commandsData.mjs';
import { handleAdminCommand } from './plugins/admin.mjs';
import { handleSecurityCommand } from './plugins/security.mjs';
import { handleChannelsCommand } from './plugins/channels.mjs';
import { handleOwnerCommand } from './plugins/owner.mjs';
import { handleProfileCommand } from './plugins/profile.mjs';
import { handleWhatsappToolsCommand } from './plugins/whatsapp.mjs';
import { handleGamesCommand } from './plugins/games.mjs';
import { handleEconomyCommand } from './plugins/economy.mjs';
import { handleMediaCommand } from './plugins/media.mjs';
import { handleStickersCommand } from './plugins/stickers.mjs';
import { handleAiCommand } from './plugins/ai.mjs';
import { handleIslamicCommand } from './plugins/islamic.mjs';
import { handleUtilitiesCommand } from './plugins/utilities.mjs';

const handledMsgIds = new Set();
const spamTracker = new Map();
const repeatTracker = new Map();

export function unwrapMessageContent(rawMsg) {
  let m = rawMsg || null;
  for (let i = 0; i < 10 && m; i++) {
    if (m.deviceSentMessage?.message) m = m.deviceSentMessage.message;
    else if (m.ephemeralMessage?.message) m = m.ephemeralMessage.message;
    else if (m.viewOnceMessage?.message) m = m.viewOnceMessage.message;
    else if (m.viewOnceMessageV2?.message) m = m.viewOnceMessageV2.message;
    else if (m.editedMessage?.message) m = m.editedMessage.message;
    else if (m.documentWithCaptionMessage?.message) m = m.documentWithCaptionMessage.message;
    else break;
  }
  return m || {};
}

export function getMessageContextInfo(msg) {
  const m = unwrapMessageContent(msg?.message);
  return (
    m.extendedTextMessage?.contextInfo ||
    m.imageMessage?.contextInfo ||
    m.videoMessage?.contextInfo ||
    m.documentMessage?.contextInfo ||
    m.buttonsResponseMessage?.contextInfo ||
    m.interactiveResponseMessage?.contextInfo ||
    null
  );
}

export function getMessageText(msg) {
  const m = unwrapMessageContent(msg?.message);
  let interactiveCmd = '';
  const nativeParams = m.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson;
  if (typeof nativeParams === 'string' && nativeParams.trim()) {
    try {
      const parsed = JSON.parse(nativeParams);
      interactiveCmd = String(parsed?.id || parsed?.command || '').trim();
    } catch {}
  }
  if (!interactiveCmd && m.interactiveResponseMessage?.body?.text?.includes('أوامر')) {
    interactiveCmd = `${config.prefix || '.'}اوامر`;
  }
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.buttonsResponseMessage?.selectedButtonId ||
    m.templateButtonReplyMessage?.selectedId ||
    m.listResponseMessage?.singleSelectReply?.selectedRowId ||
    interactiveCmd ||
    ''
  ).trim();
}

export async function handleIncomingMessage(sock, msg) {
  if (!msg?.message || msg.key?.remoteJid === 'status@broadcast') return;
  const msgId = msg.key.id || `${Date.now()}-${Math.random()}`;
  if (handledMsgIds.has(msgId)) return;
  handledMsgIds.add(msgId);
  if (handledMsgIds.size > 500) handledMsgIds.delete(handledMsgIds.values().next().value);

  const db = await loadDb();
  const chatJid = msg.key.remoteJid;
  const isGroup = chatJid.endsWith('@g.us');
  const senderJid = isGroup ? (msg.key.participant || msg.participant || chatJid) : (msg.key.fromMe ? sock.user?.id || chatJid : chatJid);
  const senderNum = (senderJid || '').split(':')[0].split('@')[0].replace(/\D/g, '');
  const botOwnNum = (sock.user?.id || '').split(':')[0].split('@')[0].replace(/\D/g, '');
  const isOwner = Boolean(msg.key.fromMe) || config.owners.includes(senderNum) || (botOwnNum && senderNum === botOwnNum);
  const pushName = msg.pushName || 'عضو الديستروفا';
  const body = getMessageText(msg);

  const user = getUser(db, senderJid, pushName);
  user.name = pushName;
  user.messages = (user.messages || 0) + 1;
  user.groupMessages = user.groupMessages || {};
  user.groupMessages[chatJid] = (user.groupMessages[chatJid] || 0) + 1;
  user.xp = (user.xp || 0) + 5;
  if (user.xp >= user.level * 150) user.level += 1;

  let groupMeta = null;
  let isAdmin = false;
  let isBotAdmin = false;
  let groupData = null;

  if (isGroup) {
    groupData = getGroup(db, chatJid);
    try {
      groupMeta = await sock.groupMetadata(chatJid);
      const botLid = (sock.user?.lid || '').split(':')[0].split('@')[0];
      const rawSenderId = (senderJid || '').split(':')[0].split('@')[0];
      const admins = groupMeta.participants.filter((p) => p.admin);
      isAdmin = isOwner || admins.some((a) => {
        const pId = (a.id || '').split(':')[0].split('@')[0];
        const pPhone = (a.phoneNumber || '').split(':')[0].split('@')[0];
        return (rawSenderId && pId === rawSenderId) || (senderNum && (pId === senderNum || pPhone === senderNum));
      });
      isBotAdmin = admins.some((a) => {
        const pId = (a.id || '').split(':')[0].split('@')[0];
        const pPhone = (a.phoneNumber || '').split(':')[0].split('@')[0];
        return (botOwnNum && (pId === botOwnNum || pPhone === botOwnNum)) || (botLid && pId === botLid);
      });
    } catch {}

    if (groupData.muted.includes(senderJid) && !isAdmin && isBotAdmin) {
      await sock.sendMessage(chatJid, { delete: msg.key }).catch(() => {});
      return;
    }

    const hasGroupLink = /(?:chat\.whatsapp\.com\/|https?:\/\/|wa\.me\/)/i.test(body);
    const hasChannelLink = /whatsapp\.com\/channel\//i.test(body);
    if ((groupData.antiLink && hasGroupLink && !hasChannelLink) || (groupData.antiChannel && hasChannelLink)) {
      if (!isAdmin && !msg.key.fromMe) {
        if (isBotAdmin) await sock.sendMessage(chatJid, { delete: msg.key }).catch(() => {});
        groupData.auditLog = (groupData.auditLog || []).slice(-29);
        groupData.auditLog.push({ ts: Date.now(), action: `حذف رابط من @${senderNum}`, by: 'auto' });
        await saveDb();
        await sock.sendMessage(chatJid, {
          text: withChannelFooter(`🛡️ تنبيه لطيف يا @${senderNum}: يُمنع إرسال الروابط في *${groupMeta?.subject || 'المجموعة'}* حفاظاً على نظام المجموعة.`),
          mentions: [senderJid],
          contextInfo: buildContextInfo(),
        }).catch(() => {});
        return;
      }
    }

    if (groupData.antiFlood && body.length > 2500 && !isAdmin && !msg.key.fromMe) {
      if (isBotAdmin) await sock.sendMessage(chatJid, { delete: msg.key }).catch(() => {});
      return;
    }

    if (groupData.antiRepeat && body && !isAdmin && !msg.key.fromMe) {
      const prev = repeatTracker.get(senderJid) || { text: '', count: 0 };
      if (prev.text === body) prev.count += 1;
      else { prev.text = body; prev.count = 1; }
      repeatTracker.set(senderJid, prev);
      if (prev.count >= 4) {
        prev.count = 0;
        if (isBotAdmin) await sock.sendMessage(chatJid, { delete: msg.key }).catch(() => {});
        await sock.sendMessage(chatJid, { text: withChannelFooter(`🛡️ تنبيه يا @${senderNum}: يرجى عدم تكرار نفس الرسالة في الشات.`), mentions: [senderJid] }).catch(() => {});
        return;
      }
    }

    if (groupData.antiSpam && !isAdmin && !msg.key.fromMe) {
      const now = Date.now();
      const prev = spamTracker.get(senderJid) || { count: 0, ts: now };
      if (now - prev.ts < 5000) prev.count += 1;
      else { prev.count = 1; prev.ts = now; }
      spamTracker.set(senderJid, prev);
      if (prev.count >= 6) {
        prev.count = 0;
        await sock.sendMessage(chatJid, { text: withChannelFooter(`🛡️ تنبيه يا @${senderNum}: يرجى التمهل في الإرسال لتجنب السبام.`), mentions: [senderJid] }).catch(() => {});
        return;
      }
    }
  }

  const prefix = db.settings.prefix || config.prefix;
  if (!body.startsWith(prefix)) {
    await saveDb();
    return;
  }
  if (user.banned && !isOwner) return;
  if (!db.settings.publicMode && !isOwner) return;
  if (db.settings.maintenance && !isOwner) {
    return sock.sendMessage(chatJid, { text: '🔧 البوت في وضع الصيانة مؤقتاً من المطور.' });
  }

  const withoutPrefix = body.slice(prefix.length).trim();
  const [rawCmd, ...args] = withoutPrefix.split(/\s+/);
  const query = args.join(' ').trim();
  const commandDef = findCommand(rawCmd);
  if (!commandDef) return;

  const startedAt = Date.now();
  db.stats.totalCommands += 1;

  const reply = async (text, reactEmoji = '⚡', mentions = []) => {
    await sock.sendMessage(chatJid, { react: { text: reactEmoji, key: msg.key } }).catch(() => {});
    const contextInfo = buildContextInfo(undefined, true);
    return sock.sendMessage(chatJid, { text, contextInfo, ...(mentions?.length ? { mentions } : {}) }).catch(() =>
      sock.sendMessage(chatJid, { text, ...(mentions?.length ? { mentions } : {}) })
    );
  };

  const replyBanner = async (text, reactEmoji = '🐉', mentions = []) => {
    await sock.sendMessage(chatJid, { react: { text: reactEmoji, key: msg.key } }).catch(() => {});
    const banner = getBannerBuffer();
    const contextInfo = buildContextInfo(undefined, true);
    if (banner) {
      try {
        return await sock.sendMessage(chatJid, { image: banner, caption: text, contextInfo, ...(mentions?.length ? { mentions } : {}) });
      } catch {}
      try {
        return await sock.sendMessage(chatJid, { image: banner, caption: text, ...(mentions?.length ? { mentions } : {}) });
      } catch {}
    }
    return reply(text, reactEmoji, mentions);
  };

  const recordError = async (cmdName, err) => {
    db.stats.totalErrors = (db.stats.totalErrors || 0) + 1;
    db.stats.errorLog = (db.stats.errorLog || []).slice(-19);
    db.stats.errorLog.push({ ts: Date.now(), cmd: cmdName, message: err?.message || String(err) });
    await saveDb();
  };

  const ctx = {
    sock, msg, chatJid, isGroup, isAdmin, isOwner, isBotAdmin, groupMeta,
    senderJid, senderNum, pushName, cmd: commandDef.cmd, args, query,
    prefix, db, config, startedAt,
    commandsCount: COMMANDS.length,
    categoriesCount: CATEGORIES.length,
    reply, replyBanner, recordError,
    unwrapMessageContent, getMessageContextInfo, downloadContentFromMessage,
    formatCategoryMenuByQuery: formatCategoryMenu,
    getResolvedChannel: getResolvedChannelInfo,
    handleIncomingMessage,
  };

  try {
    const handlers = [
      handleWhatsappToolsCommand,
      handleProfileCommand,
      handleAdminCommand,
      handleSecurityCommand,
      handleChannelsCommand,
      handleOwnerCommand,
      handleGamesCommand,
      handleEconomyCommand,
      handleMediaCommand,
      handleStickersCommand,
      handleAiCommand,
      handleIslamicCommand,
      handleUtilitiesCommand,
    ];
    for (const h of handlers) {
      const handled = await h(ctx);
      if (handled) {
        db.stats.totalSuccess = (db.stats.totalSuccess || 0) + 1;
        await saveDb();
        return;
      }
    }
  } catch (err) {
    await recordError(commandDef.cmd, err);
    await reply(withChannelFooter('⚠️ حدث خطأ أثناء تنفيذ الأمر. تم تسجيل التفاصيل للمطور.'), '⚠️');
  }
}
